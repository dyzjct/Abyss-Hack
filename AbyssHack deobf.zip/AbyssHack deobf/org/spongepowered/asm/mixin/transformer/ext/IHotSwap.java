//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package org.spongepowered.asm.mixin.transformer.ext;

public interface IHotSwap
{
    void registerMixinClass(final String p0);
    
    void registerTargetClass(final String p0, final byte[] p1);
}
