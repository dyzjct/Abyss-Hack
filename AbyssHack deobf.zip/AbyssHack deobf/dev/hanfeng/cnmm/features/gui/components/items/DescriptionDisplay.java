//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.features.gui.components.items;

import dev.hanfeng.cnmm.*;
import dev.hanfeng.cnmm.util.*;

public class DescriptionDisplay extends Item
{
    private String description;
    private boolean draw;
    
    public DescriptionDisplay(final String description, final float x, final float y) {
        super("DescriptionDisplay");
        this.description = description;
        this.setLocation(x, y);
        this.width = AbyssHack.textManager.getStringWidth(this.description) + 4;
        this.height = AbyssHack.textManager.getFontHeight() + 4;
        this.draw = false;
    }
    
    @Override
    public void drawScreen(final int mouseX, final int mouseY, final float partialTicks) {
        this.width = AbyssHack.textManager.getStringWidth(this.description) + 4;
        this.height = AbyssHack.textManager.getFontHeight() + 4;
        RenderUtil.drawRect(this.x, this.y, this.x + this.width, this.y + this.height, -704643072);
        AbyssHack.textManager.drawString(this.description, this.x + 2.0f, this.y + 2.0f, 16777215, true);
    }
    
    public boolean shouldDraw() {
        return this.draw;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(final String description) {
        this.description = description;
    }
    
    public void setDraw(final boolean draw) {
        this.draw = draw;
    }
}
