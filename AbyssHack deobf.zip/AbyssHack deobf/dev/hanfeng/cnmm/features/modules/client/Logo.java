//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.features.modules.client;

import dev.hanfeng.cnmm.features.modules.*;
import net.minecraft.util.*;
import dev.hanfeng.cnmm.features.setting.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.gui.*;
import dev.hanfeng.cnmm.event.events.*;
import dev.hanfeng.cnmm.features.*;
import dev.hanfeng.cnmm.util.*;

public class Logo extends Module
{
    public static final ResourceLocation mark;
    private int color;
    private final Setting<Float> iq;
    public Setting<Boolean> iq2;
    public Setting<Integer> imageX;
    public Setting<Integer> imageY;
    
    public Logo() {
        super("Logo", "Show AbyssHack Logo", Category.CLIENT, true, false, false);
        this.iq = (Setting<Float>)this.register(new Setting("LOGO", (T)0.0f, (T)(-1000.0f), (T)1000.0f));
        this.iq2 = (Setting<Boolean>)this.register(new Setting("LOGO1", (T)true, "Cleans your chat"));
        this.imageX = (Setting<Integer>)this.register(new Setting("x", (T)18, (T)0, (T)300, v -> this.iq2.getValue()));
        this.imageY = (Setting<Integer>)this.register(new Setting("y", (T)50, (T)0, (T)300, v -> this.iq2.getValue()));
    }
    
    @Override
    public String getDisplayInfo() {
        if (!HUD.getInstance().moduleInfo.getValue()) {
            return null;
        }
        return (float)this.iq.getValue() + "textures/logo.png";
    }
    
    public void renderLogo() {
        final int x = this.imageX.getValue();
        final int y = this.imageY.getValue();
        Util.mc.renderEngine.bindTexture(Logo.mark);
        GlStateManager.color(255.0f, 255.0f, 255.0f);
        Gui.drawScaledCustomSizeModalRect(x - 2, y - 36, 7.0f, 7.0f, 53, 53, 60, 60, 60.0f, 60.0f);
    }
    
    @Override
    public void onRender2D(final Render2DEvent event) {
        if (this.iq2.getValue() && !Feature.fullNullCheck()) {
            this.color = ColorUtil.toRGBA(ClickGui.getInstance().red.getValue(), ClickGui.getInstance().green.getValue(), ClickGui.getInstance().blue.getValue());
            if (this.enabled.getValue()) {
                this.renderLogo();
            }
        }
    }
    
    static {
        mark = new ResourceLocation("textures/logo.png");
    }
}
