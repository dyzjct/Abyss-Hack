//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.features.modules.client;

import dev.hanfeng.cnmm.features.modules.*;
import dev.hanfeng.cnmm.features.setting.*;
import dev.hanfeng.cnmm.event.events.*;
import dev.hanfeng.cnmm.*;

public class Notifications extends Module
{
    private static Notifications INSTANCE;
    public Setting<Float> speed;
    public Setting<Boolean> draw;
    
    public Notifications() {
        super("Notification", "Show Your Module Turn on/off", Category.CLIENT, true, false, false);
        this.draw = (Setting<Boolean>)this.register(new Setting("Draw", (T)true));
        this.speed = (Setting<Float>)this.register(new Setting("NotificationSpeed", (T)1.0f, (T)0.1f, (T)2.0f));
    }
    
    public static Notifications getInstance() {
        if (Notifications.INSTANCE == null) {
            Notifications.INSTANCE = new Notifications();
        }
        return Notifications.INSTANCE;
    }
    
    @Override
    public void onRender2D(final Render2DEvent event) {
        AbyssHack.notificationsManager.draw(this.speed.getValue());
    }
    
    static {
        Notifications.INSTANCE = new Notifications();
    }
}
