//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.features.modules.client;

import dev.hanfeng.cnmm.features.modules.*;
import dev.hanfeng.cnmm.features.setting.*;
import dev.hanfeng.cnmm.event.events.*;
import dev.hanfeng.cnmm.*;
import com.mojang.realmsclient.gui.*;
import dev.hanfeng.cnmm.features.command.*;
import net.minecraftforge.fml.common.eventhandler.*;
import dev.hanfeng.cnmm.features.gui.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.renderer.*;
import net.minecraft.entity.player.*;
import dev.hanfeng.cnmm.util.*;
import net.minecraft.util.*;

public class ClickGui extends Module
{
    private static ClickGui INSTANCE;
    private final Setting<Settings> setting;
    public Setting<String> prefix;
    public Setting<String> clientName;
    public Setting<Integer> red;
    public Setting<Integer> green;
    public Setting<Integer> blue;
    public Setting<Integer> hoverAlpha;
    public Setting<Integer> alpha;
    public Setting<Integer> alphaBox;
    public Setting<Boolean> outline;
    public Setting<Boolean> moduleDescription;
    public Setting<Boolean> moduleIcon;
    public Setting<Boolean> snowing;
    public Setting<Integer> iconmode;
    public Setting<Integer> moduleiconmode;
    public Setting<Integer> moduleWidth;
    public Setting<Integer> moduleDistance;
    public Setting<Boolean> rainbowg;
    public Setting<Boolean> rainbow;
    public Setting<rainbowMode> rainbowModeHud;
    public Setting<rainbowModeArray> rainbowModeA;
    public Setting<Integer> rainbowHue;
    public Setting<Float> rainbowBrightness;
    public Setting<Float> rainbowSaturation;
    public Setting<Boolean> background;
    public Setting<Boolean> blur;
    public Setting<Integer> g_red;
    public Setting<Integer> g_green;
    public Setting<Integer> g_blue;
    public Setting<Integer> g_red1;
    public Setting<Integer> g_green1;
    public Setting<Integer> g_blue1;
    public Setting<Integer> g_alpha;
    public Setting<Integer> g_alpha1;
    
    public ClickGui() {
        super("ClickGui", "Module interface.", Category.CLIENT, true, false, false);
        this.setting = (Setting<Settings>)this.register(new Setting("Settings", (T)Settings.Gui));
        this.prefix = (Setting<String>)this.register(new Setting("Prefix", (T)".", v -> this.setting.getValue() == Settings.Gui));
        this.clientName = (Setting<String>)this.register(new Setting("ClientName", (T)"AbyssHack", v -> this.setting.getValue() == Settings.Gui));
        this.red = (Setting<Integer>)this.register(new Setting("Red", (T)140, (T)0, (T)255, v -> !this.rainbow.getValue() && this.setting.getValue() == Settings.Color));
        this.green = (Setting<Integer>)this.register(new Setting("Green", (T)140, (T)0, (T)255, v -> !this.rainbow.getValue() && this.setting.getValue() == Settings.Color));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", (T)250, (T)0, (T)255, v -> !this.rainbow.getValue() && this.setting.getValue() == Settings.Color));
        this.hoverAlpha = (Setting<Integer>)this.register(new Setting("Alpha", (T)225, (T)0, (T)255, v -> !this.rainbow.getValue() && this.setting.getValue() == Settings.Color));
        this.alpha = (Setting<Integer>)this.register(new Setting("HoverAlpha", (T)240, (T)0, (T)255, v -> !this.rainbow.getValue() && this.setting.getValue() == Settings.Color));
        this.alphaBox = (Setting<Integer>)this.register(new Setting("AlphaBox", (T)0, (T)0, (T)255, v -> this.setting.getValue() == Settings.Color));
        this.outline = (Setting<Boolean>)this.register(new Setting("Outline", (T)true, v -> this.setting.getValue() == Settings.Gui));
        this.moduleDescription = (Setting<Boolean>)this.register(new Setting("Description", (T)true, v -> this.setting.getValue() == Settings.Gui));
        this.moduleIcon = (Setting<Boolean>)this.register(new Setting("Icon", (T)true, v -> this.setting.getValue() == Settings.Gui));
        this.snowing = (Setting<Boolean>)this.register(new Setting("Snowing", (T)true, v -> this.setting.getValue() == Settings.Gui));
        this.iconmode = (Setting<Integer>)this.register(new Setting("SettingIcon", (T)0, (T)0, (T)5, v -> this.setting.getValue() == Settings.Gui));
        this.moduleiconmode = (Setting<Integer>)this.register(new Setting("ModuleIcon", (T)0, (T)0, (T)2, v -> this.setting.getValue() == Settings.Gui));
        this.moduleWidth = (Setting<Integer>)this.register(new Setting("ModuleWidth", (T)0, (T)0, (T)40, v -> this.setting.getValue() == Settings.Gui));
        this.moduleDistance = (Setting<Integer>)this.register(new Setting("ModuleDistance", (T)30, (T)0, (T)50, v -> this.setting.getValue() == Settings.Gui));
        this.rainbowg = (Setting<Boolean>)this.register(new Setting("Rainbow", (T)Boolean.TRUE, v -> this.setting.getValue() == Settings.Gradient));
        this.rainbow = (Setting<Boolean>)this.register(new Setting("Rainbow", (T)Boolean.TRUE, v -> this.setting.getValue() == Settings.Color));
        this.rainbowModeHud = (Setting<rainbowMode>)this.register(new Setting("HUD", (T)rainbowMode.Static, v -> this.rainbow.getValue() && this.setting.getValue() == Settings.Color));
        this.rainbowModeA = (Setting<rainbowModeArray>)this.register(new Setting("ArrayList", (T)rainbowModeArray.Up, v -> this.rainbow.getValue() && this.setting.getValue() == Settings.Color));
        this.rainbowHue = (Setting<Integer>)this.register(new Setting("Delay", (T)600, (T)0, (T)600, v -> this.rainbow.getValue() && this.setting.getValue() == Settings.Color));
        this.rainbowBrightness = (Setting<Float>)this.register(new Setting("Brightness ", (T)255.0f, (T)1.0f, (T)255.0f, v -> this.rainbow.getValue() && this.setting.getValue() == Settings.Color));
        this.rainbowSaturation = (Setting<Float>)this.register(new Setting("Saturation", (T)255.0f, (T)1.0f, (T)255.0f, v -> this.rainbow.getValue() && this.setting.getValue() == Settings.Color));
        this.background = (Setting<Boolean>)this.register(new Setting("BackGround", (T)false, v -> this.setting.getValue() == Settings.Gui));
        this.blur = (Setting<Boolean>)this.register(new Setting("Blur", (T)false, v -> this.setting.getValue() == Settings.Gui));
        this.g_red = (Setting<Integer>)this.register(new Setting("RedL", (T)105, (T)0, (T)255, v -> this.setting.getValue() == Settings.Gradient));
        this.g_green = (Setting<Integer>)this.register(new Setting("GreenL", (T)162, (T)0, (T)255, v -> this.setting.getValue() == Settings.Gradient));
        this.g_blue = (Setting<Integer>)this.register(new Setting("BlueL", (T)255, (T)0, (T)255, v -> this.setting.getValue() == Settings.Gradient));
        this.g_red1 = (Setting<Integer>)this.register(new Setting("RedR", (T)143, (T)0, (T)255, v -> this.setting.getValue() == Settings.Gradient));
        this.g_green1 = (Setting<Integer>)this.register(new Setting("GreenR", (T)140, (T)0, (T)255, v -> this.setting.getValue() == Settings.Gradient));
        this.g_blue1 = (Setting<Integer>)this.register(new Setting("BlueR", (T)213, (T)0, (T)255, v -> this.setting.getValue() == Settings.Gradient));
        this.g_alpha = (Setting<Integer>)this.register(new Setting("AlphaL", (T)0, (T)0, (T)255, v -> this.setting.getValue() == Settings.Gradient));
        this.g_alpha1 = (Setting<Integer>)this.register(new Setting("AlphaR", (T)0, (T)0, (T)255, v -> this.setting.getValue() == Settings.Gradient));
        this.setInstance();
    }
    
    public static ClickGui getInstance() {
        if (ClickGui.INSTANCE == null) {
            ClickGui.INSTANCE = new ClickGui();
        }
        return ClickGui.INSTANCE;
    }
    
    @Override
    public void onRender2D(final Render2DEvent event) {
        if (this.background.getValue()) {
            RenderUtil.drawRect(0.0f, 0.0f, 1000.0f, 550.0f, ColorUtil.toRGBA(20, 20, 20, 150));
            RenderUtil.drawGradientRect(0, 200, 1000, 350, ColorUtil.toRGBA(this.red.getValue(), this.green.getValue(), this.blue.getValue(), 0), ColorUtil.toRGBA(this.red.getValue(), this.green.getValue(), this.blue.getValue(), 255));
        }
    }
    
    private void setInstance() {
        ClickGui.INSTANCE = this;
    }
    
    @SubscribeEvent
    public void onSettingChange(final ClientEvent event) {
        if (event.getStage() == 2 && event.getSetting().getFeature().equals(this)) {
            if (event.getSetting().equals(this.prefix)) {
                AbyssHack.commandManager.setPrefix(this.prefix.getPlannedValue());
                Command.sendMessage("Prefix set to " + ChatFormatting.DARK_GRAY + AbyssHack.commandManager.getPrefix());
            }
            AbyssHack.colorManager.setColor(this.red.getPlannedValue(), this.green.getPlannedValue(), this.blue.getPlannedValue(), this.hoverAlpha.getPlannedValue());
        }
    }
    
    public String getCommandMessage() {
        return TextUtil.coloredString("<", HUD.getInstance().bracketColor.getPlannedValue()) + TextUtil.coloredString(getInstance().clientName.getValueAsString(), HUD.getInstance().commandColor.getPlannedValue()) + TextUtil.coloredString(">", HUD.getInstance().bracketColor.getPlannedValue());
    }
    
    @Override
    public void onEnable() {
        ClickGui.mc.displayGuiScreen((GuiScreen)OyVeyGui.getClickGui());
    }
    
    @Override
    public void onLoad() {
        AbyssHack.colorManager.setColor(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.hoverAlpha.getValue());
        AbyssHack.commandManager.setPrefix(this.prefix.getValue());
    }
    
    @Override
    public void onUpdate() {
        if (this.blur.getValue()) {
            if (OpenGlHelper.shadersSupported && Util.mc.getRenderViewEntity() instanceof EntityPlayer) {
                if (Util.mc.entityRenderer.getShaderGroup() != null) {
                    Util.mc.entityRenderer.getShaderGroup().deleteShaderGroup();
                }
                try {
                    Util.mc.entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
            else if (Util.mc.entityRenderer.getShaderGroup() != null && Util.mc.currentScreen == null) {
                Util.mc.entityRenderer.getShaderGroup().deleteShaderGroup();
            }
        }
        else if (Util.mc.entityRenderer.getShaderGroup() != null) {
            Util.mc.entityRenderer.getShaderGroup().deleteShaderGroup();
        }
    }
    
    @Override
    public void onTick() {
        AbyssHack.commandManager.setClientMessage(this.getCommandMessage());
        if (!(ClickGui.mc.currentScreen instanceof OyVeyGui)) {
            this.disable();
        }
    }
    
    @Override
    public void onDisable() {
        if (ClickGui.mc.currentScreen instanceof OyVeyGui) {
            Util.mc.displayGuiScreen((GuiScreen)null);
        }
        if (Util.mc.entityRenderer.getShaderGroup() != null) {
            Util.mc.entityRenderer.getShaderGroup().deleteShaderGroup();
        }
    }
    
    static {
        ClickGui.INSTANCE = new ClickGui();
    }
    
    public enum Settings
    {
        Gui, 
        Color, 
        Gradient;
    }
    
    public enum rainbowMode
    {
        Static, 
        Sideway;
    }
    
    public enum rainbowModeArray
    {
        Static, 
        Up;
    }
}
