//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.features.modules.combat;

import dev.hanfeng.cnmm.features.modules.*;
import dev.hanfeng.cnmm.features.setting.*;
import net.minecraft.util.math.*;
import dev.hanfeng.cnmm.*;
import net.minecraft.block.*;
import java.util.*;
import net.minecraft.init.*;
import dev.hanfeng.cnmm.util.*;
import net.minecraft.network.*;
import net.minecraft.util.*;
import net.minecraft.network.play.client.*;

public class Anti32k extends Module
{
    private static Anti32k INSTANCE;
    private Setting<Integer> range;
    private Setting<Boolean> packetMine;
    public static BlockPos min;
    int oldslot;
    int shulkInt;
    HashMap<BlockPos, Integer> opendShulk;
    
    public Anti32k() {
        super("Anti32k", "Anti32k", Category.COMBAT, true, false, false);
        this.range = (Setting<Integer>)this.register(new Setting("Range", (T)5, (T)3, (T)8));
        this.packetMine = (Setting<Boolean>)this.register(new Setting("PacketMine", (T)false));
        this.oldslot = -1;
        this.opendShulk = new HashMap<BlockPos, Integer>();
    }
    
    @Override
    public void onDisable() {
        this.oldslot = -1;
        this.shulkInt = 0;
        this.opendShulk.clear();
    }
    
    @Override
    public void onTick() {
        if (fullNullCheck()) {
            return;
        }
        final Auto32k Auto32k = (Auto32k)AbyssHack.moduleManager.getModuleByDisplayName("AutoXin32k");
        final boolean b;
        final BlockPos hopperPos = BlockInteractionHelper.getSphere(EntityUtil.getLocalPlayerPosFloored(), this.range.getValue(), this.range.getValue(), false, true, 0).stream().filter(e -> {
            if (Anti32k.mc.world.getBlockState(e).getBlock() instanceof BlockHopper) {
                if (Anti32k.mc.world.getBlockState(new BlockPos(e.getX(), e.getY() + 1, e.getZ())).getBlock() instanceof BlockShulkerBox && !e.equals((Object)dev.hanfeng.cnmm.features.modules.combat.Auto32k.placeTarget)) {
                    return b;
                }
            }
            return b;
        }).min(Comparator.comparing(e -> Anti32k.mc.player.getDistanceSq(e))).orElse(null);
        final int slot = InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE);
        if (slot != -1 && hopperPos != null) {
            if (Anti32k.mc.player.getDistance((double)hopperPos.getX(), (double)hopperPos.getY(), (double)hopperPos.getZ()) > this.range.getValue()) {
                return;
            }
            if (Anti32k.mc.player.inventory.currentItem != slot) {
                this.oldslot = Anti32k.mc.player.inventory.currentItem;
                Anti32k.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot));
            }
            if (this.packetMine.getValue()) {
                Anti32k.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, hopperPos, EnumFacing.UP));
                Anti32k.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, hopperPos, EnumFacing.UP));
            }
            else {
                Anti32k.mc.playerController.onPlayerDamageBlock(hopperPos, EnumFacing.UP);
                Anti32k.mc.playerController.onPlayerDestroyBlock(hopperPos);
            }
            Anti32k.mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.MAIN_HAND));
            if (this.oldslot != -1) {
                Anti32k.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(this.oldslot));
            }
        }
    }
    
    static {
        Anti32k.INSTANCE = new Anti32k();
        Anti32k.min = null;
    }
}
