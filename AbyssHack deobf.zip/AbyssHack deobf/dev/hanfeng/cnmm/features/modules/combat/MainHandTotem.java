//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.features.modules.combat;

import dev.hanfeng.cnmm.features.modules.*;
import dev.hanfeng.cnmm.features.setting.*;
import net.minecraft.item.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.init.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;

public class MainHandTotem extends Module
{
    private final Setting<Boolean> strict;
    private final Setting<Integer> health;
    
    public MainHandTotem() {
        super("AutoTotem", "Main Hand AutoTotem", Category.COMBAT, true, false, false);
        this.strict = (Setting<Boolean>)this.register(new Setting("Strict", (T)true));
        this.health = (Setting<Integer>)this.register(new Setting("Health", (T)13, (T)0, (T)36, v -> this.strict.getValue()));
    }
    
    public static int getItemSlot(final Item item) {
        int itemSlot = -1;
        for (int i = 45; i > 0; --i) {
            if (MainHandTotem.mc.player.inventory.getStackInSlot(i).getItem().equals(item)) {
                itemSlot = i;
                break;
            }
        }
        return itemSlot;
    }
    
    @Override
    public void onUpdate() {
        if (MainHandTotem.mc.currentScreen instanceof GuiContainer && !(Offhand.mc.currentScreen instanceof GuiInventory)) {
            return;
        }
        if (MainHandTotem.mc.currentScreen instanceof GuiContainer && !(Offhand.mc.currentScreen instanceof GuiInventory)) {
            return;
        }
        if (MainHandTotem.mc.player.getHeldItemOffhand().getItem() == Items.TOTEM_OF_UNDYING) {
            return;
        }
        if (MainHandTotem.mc.player.getHeldItemMainhand().getItem() == Items.TOTEM_OF_UNDYING) {
            return;
        }
        int hotBarSlot = -1;
        final int totemSlot = getItemSlot(Items.TOTEM_OF_UNDYING);
        for (int l = 0; l < 9; ++l) {
            if (MainHandTotem.mc.player.inventory.getStackInSlot(l).getItem() == Items.TOTEM_OF_UNDYING) {
                hotBarSlot = l;
                break;
            }
        }
        final int slot = (totemSlot < 9) ? (totemSlot + 36) : totemSlot;
        if (totemSlot != -1) {
            MainHandTotem.mc.playerController.windowClick(0, slot, 0, ClickType.PICKUP, (EntityPlayer)MainHandTotem.mc.player);
            MainHandTotem.mc.playerController.windowClick(0, 36, 0, ClickType.PICKUP, (EntityPlayer)MainHandTotem.mc.player);
            MainHandTotem.mc.playerController.windowClick(0, slot, 0, ClickType.PICKUP, (EntityPlayer)MainHandTotem.mc.player);
            if ((hotBarSlot != -1 && MainHandTotem.mc.player.getHealth() <= this.health.getValue() && this.strict.getValue()) || (hotBarSlot != -1 && !this.strict.getValue())) {
                MainHandTotem.mc.player.inventory.currentItem = hotBarSlot;
            }
        }
    }
}
