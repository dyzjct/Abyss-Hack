//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.features.modules.combat;

import dev.hanfeng.cnmm.features.modules.*;
import dev.hanfeng.cnmm.features.setting.*;
import net.minecraft.entity.player.*;
import net.minecraft.entity.*;
import dev.hanfeng.cnmm.*;
import net.minecraft.init.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import net.minecraft.block.*;
import net.minecraft.util.*;
import dev.hanfeng.cnmm.util.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.item.*;
import java.util.*;
import net.minecraft.block.state.*;

public class SmartAntiCity extends Module
{
    private final Setting<Float> range;
    private final Setting<Boolean> rotate;
    private final Timer timer;
    private final Timer retryTimer;
    private final Setting<Boolean> center;
    public EntityPlayer target;
    public Setting<Boolean> packet;
    int isEn;
    private int obsidian;
    private float yaw;
    private float pitch;
    private boolean rotating;
    private boolean isSneaking;
    private BlockPos startPos;
    
    public SmartAntiCity() {
        super("SmartAntiCity", "SmartAntiCity", Category.COMBAT, true, false, false);
        this.range = (Setting<Float>)this.register(new Setting("Range", (T)8.0f, (T)1.0f, (T)12.0f));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)true));
        this.timer = new Timer();
        this.retryTimer = new Timer();
        this.center = (Setting<Boolean>)this.register(new Setting("TPCenter", (T)true));
        this.packet = (Setting<Boolean>)this.register(new Setting("Packet", (T)true));
        this.obsidian = -1;
        this.yaw = 0.0f;
        this.pitch = 0.0f;
        this.rotating = false;
    }
    
    @Override
    public void onEnable() {
        this.startPos = EntityUtil.getRoundedBlockPos((Entity)SmartAntiCity.mc.player);
        this.isEn = 1;
        if (this.center.getValue()) {
            AbyssHack.positionManager.setPositionPacket(this.startPos.getX() + 0.5, this.startPos.getY(), this.startPos.getZ() + 0.5, true, true, true);
        }
    }
    
    @Override
    public void onTick() {
        if (this.isEn != 1) {
            this.toggle();
        }
        if (!this.startPos.equals((Object)EntityUtil.getRoundedBlockPos((Entity)SmartAntiCity.mc.player))) {
            this.toggle();
        }
    }
    
    @Override
    public void onDisable() {
        this.isEn = 0;
    }
    
    @Override
    public void onUpdate() {
        final Vec3d a = SmartAntiCity.mc.player.getPositionVector();
        this.obsidian = InventoryUtil.findHotbarBlock(Blocks.OBSIDIAN);
        this.target = this.getTarget(this.range.getValue());
        if (this.target == null) {
            return;
        }
        final BlockPos feet = new BlockPos(this.target.posX, this.target.posY, this.target.posZ);
        final BlockPos pos = new BlockPos(SmartAntiCity.mc.player.posX, SmartAntiCity.mc.player.posY, SmartAntiCity.mc.player.posZ);
        if (this.obsidian == -1) {
            return;
        }
        if (this.checkCrystal(a, EntityUtil.getVarOffsets(0, 1, 1)) != null && this.checkCrystal(a, EntityUtil.getVarOffsets(0, 1, 2)) != null) {
            EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(0, 1, 1)), true);
            this.place(a, EntityUtil.getVarOffsets(0, 1, 1));
        }
        if (this.checkCrystal(a, EntityUtil.getVarOffsets(0, 1, -1)) != null && this.checkCrystal(a, EntityUtil.getVarOffsets(0, 1, -2)) != null) {
            EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(0, 1, -1)), true);
            this.place(a, EntityUtil.getVarOffsets(0, 1, -1));
        }
        if (this.checkCrystal(a, EntityUtil.getVarOffsets(1, 1, 0)) != null && this.checkCrystal(a, EntityUtil.getVarOffsets(2, 1, 0)) != null) {
            EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(1, 1, 0)), true);
            this.place(a, EntityUtil.getVarOffsets(1, 1, 0));
        }
        if (this.checkCrystal(a, EntityUtil.getVarOffsets(-1, 1, 0)) != null && this.checkCrystal(a, EntityUtil.getVarOffsets(-2, 1, 0)) != null) {
            EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(-1, 1, 0)), true);
            this.place(a, EntityUtil.getVarOffsets(-1, 1, 0));
        }
        if (this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, 1)) != null && this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, 2)) != null) {
            EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, 1)), true);
            this.place(a, EntityUtil.getVarOffsets(0, 0, 1));
        }
        if (this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, -1)) != null && this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, -2)) != null) {
            EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, -1)), true);
            this.place(a, EntityUtil.getVarOffsets(0, 0, -1));
        }
        if (this.checkCrystal(a, EntityUtil.getVarOffsets(1, 0, 0)) != null && this.checkCrystal(a, EntityUtil.getVarOffsets(2, 0, 0)) != null) {
            EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(1, 0, 0)), true);
            this.place(a, EntityUtil.getVarOffsets(1, 0, 0));
        }
        if (this.checkCrystal(a, EntityUtil.getVarOffsets(-1, 0, 0)) != null && this.checkCrystal(a, EntityUtil.getVarOffsets(-2, 0, 0)) != null) {
            EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(-1, 0, 0)), true);
            this.place(a, EntityUtil.getVarOffsets(-1, 0, 0));
        }
        if (this.getBlock(pos.add(1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(2, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(2, 1, 0)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(2, 1, 0)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(2, 1, 0)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(2, 1, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, 0)))) {
                this.perform(pos.add(2, 1, 0));
            }
        }
        if (this.getBlock(pos.add(-1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(-2, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(-2, 1, 0)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(-2, 1, 0)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(-2, 1, 0)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-2, 1, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, 0)))) {
                this.perform(pos.add(-2, 1, 0));
            }
        }
        if (this.getBlock(pos.add(0, 0, 1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(0, 0, 2)).getBlock() == Blocks.AIR && this.getBlock(pos.add(0, 1, 2)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(0, 1, 2)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(0, 1, 2)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, 2))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 2)))) {
                this.perform(pos.add(0, 1, 2));
            }
        }
        if (this.getBlock(pos.add(0, 0, -1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(0, 0, -2)).getBlock() == Blocks.AIR && this.getBlock(pos.add(0, 1, -2)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(0, 1, -2)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(0, 1, -2)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, -2))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -2)))) {
                this.perform(pos.add(0, 1, -2));
            }
        }
        if (this.getBlock(pos.add(0, 0, 1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(0, -1, 1)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, 1)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, 1)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, -2, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, 1)))) {
                this.perform(pos.add(0, -1, 1));
                this.perform(pos.add(0, 0, 1));
            }
        }
        if (this.getBlock(pos.add(0, 0, -1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(0, -1, -1)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, -1)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, -1)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, -2, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, -1)))) {
                this.perform(pos.add(0, -1, -1));
                this.perform(pos.add(0, 0, -1));
            }
        }
        if (this.getBlock(pos.add(1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(1, -1, 0)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(1, 0, 0)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(1, 0, 0)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, -2, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 0)))) {
                this.perform(pos.add(1, -1, 0));
                this.perform(pos.add(1, 0, 0));
            }
        }
        if (this.getBlock(pos.add(-1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(-1, -1, 0)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(-1, 0, 0)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(-1, 0, 0)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, -2, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 0)))) {
                this.perform(pos.add(-1, -1, 0));
                this.perform(pos.add(-1, 0, 0));
            }
        }
        if (this.getBlock(pos.add(0, 0, 1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(0, 0, 2)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, 2)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, 2)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 2))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, 2)))) {
                if (this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, 2)) == null) {
                    this.perform(pos.add(0, 0, 1));
                    this.perform(pos.add(0, 0, 2));
                    this.perform(pos.add(0, -1, 2));
                    this.perform(pos.add(0, 0, 3));
                }
                else if (this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, 2)) != null && this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, 1)) != null) {
                    EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, 2)), true);
                    this.perform(pos.add(0, 0, 1));
                    this.perform(pos.add(0, 0, 2));
                    this.perform(pos.add(0, -1, 2));
                    this.perform(pos.add(0, 0, 3));
                }
            }
        }
        if (this.getBlock(pos.add(0, 0, -1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(0, 0, -2)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, -2)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, -2)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -2))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, -2)))) {
                if (this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, -2)) == null) {
                    this.perform(pos.add(0, 0, -1));
                    this.perform(pos.add(0, 0, -2));
                    this.perform(pos.add(0, -1, -2));
                    this.perform(pos.add(0, 0, -3));
                }
                else if (this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, -2)) != null && this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, -1)) != null) {
                    EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(0, 0, -2)), true);
                    this.perform(pos.add(0, 0, -1));
                    this.perform(pos.add(0, 0, -2));
                    this.perform(pos.add(0, -1, -2));
                    this.perform(pos.add(0, 0, -3));
                }
            }
        }
        if (this.getBlock(pos.add(1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(2, 0, 0)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(2, 0, 0)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(2, 0, 0)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(2, -1, 0)))) {
                if (this.checkCrystal(a, EntityUtil.getVarOffsets(2, 0, 0)) == null) {
                    this.perform(pos.add(1, 0, 0));
                    this.perform(pos.add(2, 0, 0));
                    this.perform(pos.add(2, -1, 0));
                    this.perform(pos.add(3, 0, 0));
                }
                else if (this.checkCrystal(a, EntityUtil.getVarOffsets(2, 0, 0)) != null && this.checkCrystal(a, EntityUtil.getVarOffsets(1, 0, 0)) != null) {
                    EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(2, 0, 0)), true);
                    this.perform(pos.add(1, 0, 0));
                    this.perform(pos.add(2, 0, 0));
                    this.perform(pos.add(2, -1, 0));
                    this.perform(pos.add(3, 0, 0));
                }
            }
        }
        if (this.getBlock(pos.add(-1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(-2, 0, 0)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(-2, 0, 0)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(-2, 0, 0)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-2, -1, 0)))) {
                if (this.checkCrystal(a, EntityUtil.getVarOffsets(-2, 0, 0)) == null) {
                    this.perform(pos.add(-1, 0, 0));
                    this.perform(pos.add(-2, 0, 0));
                    this.perform(pos.add(-2, -1, 0));
                    this.perform(pos.add(-3, 0, 0));
                }
                else if (this.checkCrystal(a, EntityUtil.getVarOffsets(-2, 0, 0)) != null && this.checkCrystal(a, EntityUtil.getVarOffsets(-1, 0, 0)) != null) {
                    EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(-2, 0, 0)), true);
                    this.perform(pos.add(-1, 0, 0));
                    this.perform(pos.add(-2, 0, 0));
                    this.perform(pos.add(-2, -1, 0));
                    this.perform(pos.add(-3, 0, 0));
                }
            }
        }
        if (this.getBlock(pos.add(0, 0, 1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(0, 1, 1)).getBlock() == Blocks.AIR) {
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, 1)))) {
                if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 1)))) {
                    this.perform(pos.add(0, 0, 1));
                    this.perform(pos.add(0, 1, 1));
                    this.perform(pos.add(1, 1, 1));
                    this.perform(pos.add(0, 1, 2));
                }
            }
            else if (this.getBlock(pos.add(0, 0, 2)).getBlock() == Blocks.AIR && this.getBlock(pos.add(0, 1, 2)).getBlock() == Blocks.AIR) {
                this.perform(pos.add(0, 0, 2));
                this.perform(pos.add(0, 1, 2));
                this.perform(pos.add(1, 0, 2));
                this.perform(pos.add(1, 1, 2));
            }
        }
        if (this.getBlock(pos.add(0, 0, -1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(0, 1, -1)).getBlock() == Blocks.AIR) {
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, -1)))) {
                if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -1)))) {
                    this.perform(pos.add(0, 0, -1));
                    this.perform(pos.add(0, 1, -1));
                    this.perform(pos.add(-1, 1, -1));
                    this.perform(pos.add(0, 1, -2));
                }
            }
            else if (this.getBlock(pos.add(0, 0, -2)).getBlock() == Blocks.AIR && this.getBlock(pos.add(0, 1, -2)).getBlock() == Blocks.AIR) {
                this.perform(pos.add(0, 0, -2));
                this.perform(pos.add(0, 1, -2));
                this.perform(pos.add(1, 0, -2));
                this.perform(pos.add(1, 1, -2));
            }
        }
        if (this.getBlock(pos.add(1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(1, 1, 0)).getBlock() == Blocks.AIR) {
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 0)))) {
                if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 0)))) {
                    this.perform(pos.add(1, 0, 0));
                    this.perform(pos.add(1, 1, 0));
                    this.perform(pos.add(1, 1, 1));
                    this.perform(pos.add(2, 1, 0));
                }
            }
            else if (this.getBlock(pos.add(2, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(2, 1, 0)).getBlock() == Blocks.AIR) {
                this.perform(pos.add(2, 0, 0));
                this.perform(pos.add(2, 1, 0));
                this.perform(pos.add(2, 0, 1));
                this.perform(pos.add(2, 1, 1));
            }
        }
        if (this.getBlock(pos.add(-1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(-1, 1, 0)).getBlock() == Blocks.AIR) {
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 0)))) {
                if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 0)))) {
                    this.perform(pos.add(-1, 0, 0));
                    this.perform(pos.add(-1, 1, 0));
                    this.perform(pos.add(-1, 1, -1));
                    this.perform(pos.add(-2, 1, 0));
                }
            }
            else if (this.getBlock(pos.add(-2, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(-2, 1, 0)).getBlock() == Blocks.AIR) {
                this.perform(pos.add(-2, 0, 0));
                this.perform(pos.add(-2, 1, 0));
                this.perform(pos.add(-2, 0, 1));
                this.perform(pos.add(-2, 1, 1));
            }
        }
        if (this.getBlock(pos.add(1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(1, 0, 1)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(1, 0, 1)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(1, 0, 1)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 1)))) {
                this.perform(pos.add(1, 0, 0));
                this.perform(pos.add(1, 0, 1));
            }
        }
        if (this.getBlock(pos.add(0, 0, 1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(1, 0, 1)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(1, 0, 1)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(1, 0, 1)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 1)))) {
                this.perform(pos.add(0, 0, 1));
                this.perform(pos.add(1, 0, 1));
            }
        }
        if (this.getBlock(pos.add(-1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(-1, 0, -1)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(-1, 0, -1)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(-1, 0, -1)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, -1)))) {
                this.perform(pos.add(-1, 0, 0));
                this.perform(pos.add(-1, 0, -1));
            }
        }
        if (this.getBlock(pos.add(0, 0, -1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(-1, 0, -1)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(-1, 0, -1)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(-1, 0, -1)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, -1)))) {
                this.perform(pos.add(0, 0, -1));
                this.perform(pos.add(-1, 0, -1));
            }
        }
        if (this.getBlock(pos.add(-1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(-1, 0, 1)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(-1, 0, 1)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(-1, 0, 1)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 1)))) {
                this.perform(pos.add(-1, 0, 0));
                this.perform(pos.add(-1, 0, 1));
            }
        }
        if (this.getBlock(pos.add(0, 0, 1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(-1, 0, 1)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(-1, 0, 1)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(-1, 0, 1)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 1)))) {
                this.perform(pos.add(0, 0, 1));
                this.perform(pos.add(-1, 0, 1));
            }
        }
        if (this.getBlock(pos.add(1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(1, 0, -1)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(1, 0, -1)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(1, 0, -1)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, -1)))) {
                this.perform(pos.add(1, 0, 0));
                this.perform(pos.add(1, 0, -1));
            }
        }
        if (this.getBlock(pos.add(0, 0, -1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(1, 0, -1)).getBlock() == Blocks.AIR) {
            if (this.checkCrystal(a, EntityUtil.getVarOffsets(1, 0, -1)) != null) {
                EntityUtil.attackEntity(this.checkCrystal(a, EntityUtil.getVarOffsets(1, 0, -1)), true);
            }
            if (!new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, -1)))) {
                this.perform(pos.add(0, 0, -1));
                this.perform(pos.add(1, 0, -1));
            }
        }
        if (this.getBlock(pos.add(1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(1, 0, 1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(1, 1, 1)).getBlock() == Blocks.AIR && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 0)))) {
            this.perform(pos.add(1, 0, 0));
            this.perform(pos.add(1, 0, 1));
            this.perform(pos.add(1, 1, 1));
        }
        if (this.getBlock(pos.add(0, 0, 1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(1, 0, 1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(1, 1, 1)).getBlock() == Blocks.AIR && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, 1)))) {
            this.perform(pos.add(0, 0, 1));
            this.perform(pos.add(1, 0, 1));
            this.perform(pos.add(1, 1, 1));
        }
        if (this.getBlock(pos.add(-1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(-1, 0, -1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(-1, 1, -1)).getBlock() == Blocks.AIR && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 0)))) {
            this.perform(pos.add(-1, 0, 0));
            this.perform(pos.add(-1, 0, -1));
            this.perform(pos.add(-1, 1, -1));
        }
        if (this.getBlock(pos.add(0, 0, -1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(-1, 0, -1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(-1, 1, -1)).getBlock() == Blocks.AIR && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, -1)))) {
            this.perform(pos.add(0, 0, -1));
            this.perform(pos.add(-1, 0, -1));
            this.perform(pos.add(-1, 1, -1));
        }
        if (this.getBlock(pos.add(-1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(-1, 0, 1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(-1, 1, 1)).getBlock() == Blocks.AIR && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 0)))) {
            this.perform(pos.add(-1, 0, 0));
            this.perform(pos.add(-1, 0, 1));
            this.perform(pos.add(-1, 1, 1));
        }
        if (this.getBlock(pos.add(0, 0, 1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(-1, 0, 1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(-1, 1, 1)).getBlock() == Blocks.AIR && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, 1)))) {
            this.perform(pos.add(0, 0, 1));
            this.perform(pos.add(-1, 0, 1));
            this.perform(pos.add(-1, 1, 1));
        }
        if (this.getBlock(pos.add(1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(pos.add(1, 0, -1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(1, 1, -1)).getBlock() == Blocks.AIR && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 0))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 0)))) {
            this.perform(pos.add(1, 0, 0));
            this.perform(pos.add(1, 0, -1));
            this.perform(pos.add(1, 1, -1));
        }
        if (this.getBlock(pos.add(0, 0, -1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(1, 0, -1)).getBlock() == Blocks.AIR && this.getBlock(pos.add(1, 1, -1)).getBlock() == Blocks.AIR && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -1))) && !new BlockPos((Vec3i)feet).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, -1)))) {
            this.perform(pos.add(0, 0, -1));
            this.perform(pos.add(1, 0, -1));
            this.perform(pos.add(1, 1, -1));
        }
    }
    
    private void switchToSlot(final int slot) {
        SmartAntiCity.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot));
        SmartAntiCity.mc.player.inventory.currentItem = slot;
        SmartAntiCity.mc.playerController.updateController();
    }
    
    private void place(final Vec3d pos, final Vec3d[] list) {
        final Vec3d[] var3 = list;
        for (int var4 = list.length, var5 = 0; var5 < var4; ++var5) {
            final Vec3d vec3d = var3[var5];
            final BlockPos position = new BlockPos(pos).add(vec3d.x, vec3d.y, vec3d.z);
            final int a = SmartAntiCity.mc.player.inventory.currentItem;
            SmartAntiCity.mc.player.inventory.currentItem = InventoryUtil.findHotbarBlock(BlockObsidian.class);
            SmartAntiCity.mc.playerController.updateController();
            this.isSneaking = BlockUtil.placeBlock(position, EnumHand.MAIN_HAND, false, this.packet.getValue(), true);
            SmartAntiCity.mc.player.inventory.currentItem = a;
            SmartAntiCity.mc.playerController.updateController();
        }
    }
    
    Entity checkCrystal(final Vec3d pos, final Vec3d[] list) {
        Entity crystal = null;
        final Vec3d[] var4 = list;
        for (int var5 = list.length, var6 = 0; var6 < var5; ++var6) {
            final Vec3d vec3d = var4[var6];
            final BlockPos position = new BlockPos(pos).add(vec3d.x, vec3d.y, vec3d.z);
            for (final Entity entity : SmartAntiCity.mc.world.getEntitiesWithinAABB((Class)Entity.class, new AxisAlignedBB(position))) {
                if (entity instanceof EntityEnderCrystal) {
                    if (crystal != null) {
                        continue;
                    }
                    crystal = entity;
                }
            }
        }
        return crystal;
    }
    
    private IBlockState getBlock(final BlockPos block) {
        return SmartAntiCity.mc.world.getBlockState(block);
    }
    
    private EntityPlayer getTarget(final double range) {
        EntityPlayer target = null;
        double distance = Math.pow(range, 2.0) + 1.0;
        for (final EntityPlayer player : SmartAntiCity.mc.world.playerEntities) {
            if (!EntityUtil.isntValid((Entity)player, range)) {
                if (AbyssHack.speedManager.getPlayerSpeed(player) > 10.0) {
                    continue;
                }
                if (target == null) {
                    target = player;
                    distance = SmartAntiCity.mc.player.getDistanceSq((Entity)player);
                }
                else {
                    if (SmartAntiCity.mc.player.getDistanceSq((Entity)player) >= distance) {
                        continue;
                    }
                    target = player;
                    distance = SmartAntiCity.mc.player.getDistanceSq((Entity)player);
                }
            }
        }
        return target;
    }
    
    private void perform(final BlockPos pos) {
        final int old = SmartAntiCity.mc.player.inventory.currentItem;
        this.switchToSlot(this.obsidian);
        BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
        this.switchToSlot(old);
    }
}
