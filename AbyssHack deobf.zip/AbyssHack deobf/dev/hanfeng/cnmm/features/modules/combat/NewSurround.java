//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.features.modules.combat;

import dev.hanfeng.cnmm.features.modules.*;
import dev.hanfeng.cnmm.features.setting.*;
import net.minecraft.entity.*;
import dev.hanfeng.cnmm.*;
import net.minecraft.init.*;
import net.minecraft.entity.player.*;
import net.minecraft.entity.item.*;
import java.util.stream.*;
import net.minecraft.network.*;
import net.minecraft.util.*;
import net.minecraft.network.play.client.*;
import java.util.*;
import net.minecraft.block.*;
import dev.hanfeng.cnmm.util.*;
import net.minecraft.util.math.*;

public class NewSurround extends Module
{
    public Setting<Boolean> rotate;
    private final Setting<Boolean> center;
    BlockPos startPos;
    BlockPos FeetPos;
    BlockPos CrystalPos;
    
    public NewSurround() {
        super("NewSurround", "Surrounds you in 2b2t.xin with Obsidian.", Category.COMBAT, true, false, false);
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)true));
        this.center = (Setting<Boolean>)this.register(new Setting("TPCenter", (T)true));
        this.CrystalPos = null;
    }
    
    @Override
    public void onEnable() {
        this.startPos = EntityUtil.getRoundedBlockPos((Entity)Surround.mc.player);
        if (this.center.getValue()) {
            AbyssHack.positionManager.setPositionPacket(this.startPos.getX() + 0.5, this.startPos.getY(), this.startPos.getZ() + 0.5, true, true, true);
        }
    }
    
    @Override
    public void onUpdate() {
        if (this.startPos == null) {
            this.disable();
            return;
        }
        if (!this.startPos.equals((Object)EntityUtil.getRoundedBlockPos((Entity)Surround.mc.player))) {
            this.disable();
            return;
        }
        final BlockPos pos = new BlockPos(NewSurround.mc.player.posX, NewSurround.mc.player.posY, NewSurround.mc.player.posZ);
        final EntityPlayer target = this.getTarget();
        this.FeetPos = ((target != null) ? new BlockPos(target.posX, target.posY, target.posZ) : null);
        final Entity crystal = this.getEndCrystal();
        if (crystal != null) {
            this.CrystalPos = new BlockPos(crystal.posX, crystal.posY, crystal.posZ);
            if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 1)))) {
                AttackCrystal(pos.add(0, 0, 1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -1)))) {
                AttackCrystal(pos.add(0, 0, -1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 0)))) {
                AttackCrystal(pos.add(1, 0, 0));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 0)))) {
                AttackCrystal(pos.add(-1, 0, 0));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, 1)))) {
                AttackCrystal(pos.add(0, -1, 1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, -1)))) {
                AttackCrystal(pos.add(0, -1, -1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 0)))) {
                AttackCrystal(pos.add(1, -1, 0));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 0)))) {
                AttackCrystal(pos.add(-1, -1, 0));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 2)))) {
                AttackCrystal(pos.add(0, 0, 2));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -2)))) {
                AttackCrystal(pos.add(0, 0, -2));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, 0)))) {
                AttackCrystal(pos.add(2, 0, 0));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, 0)))) {
                AttackCrystal(pos.add(-2, 0, 0));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, 2)))) {
                AttackCrystal(pos.add(0, 1, 2));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, -2)))) {
                AttackCrystal(pos.add(0, 1, -2));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 1, 0)))) {
                AttackCrystal(pos.add(2, 1, 0));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 1, 0)))) {
                AttackCrystal(pos.add(-2, 1, 0));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, 2)))) {
                AttackCrystal(pos.add(0, -1, 2));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, -2)))) {
                AttackCrystal(pos.add(0, -1, -2));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(2, -1, 0)))) {
                AttackCrystal(pos.add(2, -1, 0));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, -1, 0)))) {
                AttackCrystal(pos.add(-2, -1, 0));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 1)))) {
                AttackCrystal(pos.add(1, 0, 1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, -1)))) {
                AttackCrystal(pos.add(1, 0, -1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, -1)))) {
                AttackCrystal(pos.add(-1, 0, -1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 1)))) {
                AttackCrystal(pos.add(-1, 0, 1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 1)))) {
                AttackCrystal(pos.add(1, -1, 1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, -1)))) {
                AttackCrystal(pos.add(1, -1, -1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, -1)))) {
                AttackCrystal(pos.add(-1, -1, -1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 1)))) {
                AttackCrystal(pos.add(-1, -1, 1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, 1)))) {
                AttackCrystal(pos.add(2, 0, 1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, -1)))) {
                AttackCrystal(pos.add(2, 0, -1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, -1)))) {
                AttackCrystal(pos.add(-2, 0, -1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, 1)))) {
                AttackCrystal(pos.add(-2, 0, 1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 2)))) {
                AttackCrystal(pos.add(1, 0, 2));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, -2)))) {
                AttackCrystal(pos.add(1, 0, -2));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, -2)))) {
                AttackCrystal(pos.add(-1, 0, -2));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 2)))) {
                AttackCrystal(pos.add(-1, 0, 2));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(2, -1, 1)))) {
                AttackCrystal(pos.add(2, -1, 1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(2, -1, -1)))) {
                AttackCrystal(pos.add(2, -1, -1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, -1, -1)))) {
                AttackCrystal(pos.add(-2, -1, -1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, -1, 1)))) {
                AttackCrystal(pos.add(-2, -1, 1));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 2)))) {
                AttackCrystal(pos.add(1, -1, 2));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, -2)))) {
                AttackCrystal(pos.add(1, -1, -2));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, -2)))) {
                AttackCrystal(pos.add(-1, -1, -2));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 2)))) {
                AttackCrystal(pos.add(-1, -1, 2));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, 2)))) {
                AttackCrystal(pos.add(2, 0, 2));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, -2)))) {
                AttackCrystal(pos.add(2, 0, -2));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, -2)))) {
                AttackCrystal(pos.add(-2, 0, -2));
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, 2)))) {
                AttackCrystal(pos.add(-2, 0, 2));
            }
        }
        if (NewSurround.mc.world.getBlockState(pos.add(0, -1, -1)).getBlock() != Blocks.AIR && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, -1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -1)))) && NewSurround.mc.world.getBlockState(pos.add(0, 0, -1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(0, 0, -1));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, -1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -2, -1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, -1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, -1)))) && NewSurround.mc.world.getBlockState(pos.add(0, -1, -1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(0, -1, -1));
        }
        if (NewSurround.mc.world.getBlockState(pos.add(-1, -1, 0)).getBlock() != Blocks.AIR && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 0)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 0)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 0)))) && NewSurround.mc.world.getBlockState(pos.add(-1, 0, 0)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(-1, 0, 0));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -2, 0)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 0)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 0)))) && NewSurround.mc.world.getBlockState(pos.add(-1, -1, 0)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(-1, -1, 0));
        }
        if (NewSurround.mc.world.getBlockState(pos.add(1, -1, 0)).getBlock() != Blocks.AIR && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 0)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 0)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 0)))) && NewSurround.mc.world.getBlockState(pos.add(1, 0, 0)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(1, 0, 0));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -2, 0)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 0)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 0)))) && NewSurround.mc.world.getBlockState(pos.add(1, -1, 0)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(1, -1, 0));
        }
        if (NewSurround.mc.world.getBlockState(pos.add(0, -1, 1)).getBlock() != Blocks.AIR && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, 1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 1)))) && NewSurround.mc.world.getBlockState(pos.add(0, 0, 1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(0, 0, 1));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, 1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -2, 1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, 1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, 1)))) && NewSurround.mc.world.getBlockState(pos.add(0, -1, 1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(0, -1, 1));
        }
        else if (this.checkCrystal(EntityUtil.getVarOffsets(0, 0, 2)) == null && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 2)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, 2)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 2)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 2)))) && NewSurround.mc.world.getBlockState(pos.add(0, 0, 2)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(0, 0, 2));
        }
        else if (this.checkCrystal(EntityUtil.getVarOffsets(0, 0, -2)) == null && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -2)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, -2)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -2)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -2)))) && NewSurround.mc.world.getBlockState(pos.add(0, 0, -2)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(0, 0, -2));
        }
        else if (this.checkCrystal(EntityUtil.getVarOffsets(2, 0, 0)) == null && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(2, -1, 0)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, 0)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, 0)))) && NewSurround.mc.world.getBlockState(pos.add(2, 0, 0)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(2, 0, 0));
        }
        else if (this.checkCrystal(EntityUtil.getVarOffsets(-3, 0, 0)) == null && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, -1, 0)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, 0)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, 0)))) && NewSurround.mc.world.getBlockState(pos.add(-2, 0, 0)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(-2, 0, 0));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 1)))) && NewSurround.mc.world.getBlockState(pos.add(1, 0, 1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(1, 0, 1));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 1)))) && NewSurround.mc.world.getBlockState(pos.add(-1, 0, 1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(-1, 0, 1));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, -1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, -1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, -1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, -1)))) && NewSurround.mc.world.getBlockState(pos.add(1, 0, -1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(1, 0, -1));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, -1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, -1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, -1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, -1)))) && NewSurround.mc.world.getBlockState(pos.add(-1, 0, -1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(-1, 0, -1));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, 2)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 2)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, 2)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, 2)))) && NewSurround.mc.world.getBlockState(pos.add(0, 1, 2)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(0, 1, 2));
            if (this.checkCrystal(EntityUtil.getVarOffsets(1, 1, 2)) == null && NewSurround.mc.world.getBlockState(pos.add(0, 0, 1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(0, 1, 2)).getBlock() == Blocks.AIR) {
                this.perform(pos.add(1, 0, 2));
                this.perform(pos.add(1, 1, 2));
            }
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, -2)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -2)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, -2)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, -2)))) && NewSurround.mc.world.getBlockState(pos.add(0, 1, -2)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(0, 1, -2));
            if (this.checkCrystal(EntityUtil.getVarOffsets(-1, 1, -2)) == null && NewSurround.mc.world.getBlockState(pos.add(0, 0, -1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(0, 1, -2)).getBlock() == Blocks.AIR) {
                this.perform(pos.add(-1, 0, -2));
                this.perform(pos.add(-1, 1, -2));
            }
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 1, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, 0)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 1, 0)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 1, 0)))) && NewSurround.mc.world.getBlockState(pos.add(2, 1, 0)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(2, 1, 0));
            if (this.checkCrystal(EntityUtil.getVarOffsets(2, 1, 1)) == null && NewSurround.mc.world.getBlockState(pos.add(1, 0, 0)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(2, 1, 0)).getBlock() == Blocks.AIR) {
                this.perform(pos.add(2, 0, 1));
                this.perform(pos.add(2, 1, 1));
            }
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 1, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, 0)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 1, 0)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 1, 0)))) && NewSurround.mc.world.getBlockState(pos.add(-2, 1, 0)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(-2, 1, 0));
            if (this.checkCrystal(EntityUtil.getVarOffsets(-2, 1, -1)) == null && NewSurround.mc.world.getBlockState(pos.add(-1, 0, 0)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(-2, 1, 0)).getBlock() == Blocks.AIR) {
                this.perform(pos.add(-2, 0, -1));
                this.perform(pos.add(-2, 1, -1));
            }
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 0)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, 0)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, 0)))) && NewSurround.mc.world.getBlockState(pos.add(-1, 1, 0)).getBlock() == Blocks.AIR && (NewSurround.mc.world.getBlockState(pos.add(-1, 0, 0)).getBlock() == Blocks.AIR || (InstantMine.breakPos != null && new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 0)))) || (BreakCheck.Instance().BrokenPos != null && new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 0)))))) {
            this.perform(pos.add(-1, 1, 0));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 0)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, 0)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, 0)))) && NewSurround.mc.world.getBlockState(pos.add(1, 1, 0)).getBlock() == Blocks.AIR && (NewSurround.mc.world.getBlockState(pos.add(1, 0, 0)).getBlock() == Blocks.AIR || (InstantMine.breakPos != null && new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 0)))) || (BreakCheck.Instance().BrokenPos != null && new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 0)))))) {
            this.perform(pos.add(1, 1, 0));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, 1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, 1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, 1)))) && NewSurround.mc.world.getBlockState(pos.add(0, 1, 1)).getBlock() == Blocks.AIR && (NewSurround.mc.world.getBlockState(pos.add(0, 0, 1)).getBlock() == Blocks.AIR || (InstantMine.breakPos != null && new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 1)))) || (BreakCheck.Instance().BrokenPos != null && new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 1)))))) {
            this.perform(pos.add(0, 1, 1));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, -1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, -1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, -1)))) && NewSurround.mc.world.getBlockState(pos.add(0, 1, -1)).getBlock() == Blocks.AIR && (NewSurround.mc.world.getBlockState(pos.add(0, 0, -1)).getBlock() == Blocks.AIR || (InstantMine.breakPos != null && new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -1)))) || (BreakCheck.Instance().BrokenPos != null && new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -1)))))) {
            this.perform(pos.add(0, 1, -1));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 2, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, 0)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 2, 0)))) && BreakCheck.Instance().BrokenPos != null && new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, 0))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 2, 0)))) && NewSurround.mc.world.getBlockState(pos.add(-1, 2, 0)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(-1, 1, 0)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(0, 2, 0)).getBlock() != Blocks.AIR) {
            this.perform(pos.add(-1, 2, 0));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 2, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, 0)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 2, 0)))) && BreakCheck.Instance().BrokenPos != null && new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, 0))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 2, 0)))) && NewSurround.mc.world.getBlockState(pos.add(1, 2, 0)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(1, 1, 0)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(0, 2, 0)).getBlock() != Blocks.AIR) {
            this.perform(pos.add(1, 2, 0));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 2, 1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, 1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 2, 1)))) && BreakCheck.Instance().BrokenPos != null && new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, 1))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 2, 1)))) && NewSurround.mc.world.getBlockState(pos.add(0, 2, 1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(0, 1, 1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(0, 2, 0)).getBlock() != Blocks.AIR) {
            this.perform(pos.add(0, 2, 1));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 2, -1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, -1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 2, -1)))) && BreakCheck.Instance().BrokenPos != null && new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, -1))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 2, -1)))) && NewSurround.mc.world.getBlockState(pos.add(0, 2, -1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(0, 1, -1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(0, 2, 0)).getBlock() != Blocks.AIR) {
            this.perform(pos.add(0, 2, -1));
        }
        else if ((this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-3, 0, 0)))) && (this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-3, -1, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-3, 0, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-3, -1, 0)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-3, 0, 0)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-3, 0, 0)))) && NewSurround.mc.world.getBlockState(pos.add(-3, 0, 0)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(-1, 0, 0)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(-2, 0, 0)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(-3, 0, 0));
        }
        else if ((this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(3, 0, 0)))) && (this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(3, -1, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(3, 0, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(3, -1, 0)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(3, 0, 0)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(3, 0, 0)))) && NewSurround.mc.world.getBlockState(pos.add(3, 0, 0)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(1, 0, 0)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(2, 0, 0)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(3, 0, 0));
        }
        else if ((this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 3)))) && (this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, 3)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 3)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, 3)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 3)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 3)))) && NewSurround.mc.world.getBlockState(pos.add(0, 0, 3)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(0, 0, 1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(0, 0, 2)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(0, 0, 3));
        }
        else if ((this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -3)))) && (this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, -3)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -3)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, -3)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -3)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -3)))) && NewSurround.mc.world.getBlockState(pos.add(0, 0, -3)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(0, 0, -1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(0, 0, -2)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(0, 0, -3));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, 1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, 1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, 1)))) && NewSurround.mc.world.getBlockState(pos.add(-1, 1, 1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(-1, 0, 1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(-1, 1, 1));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, 1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, 1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, 1)))) && NewSurround.mc.world.getBlockState(pos.add(1, 1, 1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(1, 0, 1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(1, 1, 1));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, -1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, -1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, -1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, -1)))) && NewSurround.mc.world.getBlockState(pos.add(-1, 1, -1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(-1, 0, -1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(-1, 1, -1));
        }
        else if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, -1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, -1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, -1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, -1)))) && NewSurround.mc.world.getBlockState(pos.add(1, 1, -1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(1, 0, -1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(1, 1, -1));
        }
        else if ((this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, 1)))) && (this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, 1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, 1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, 1)))) && NewSurround.mc.world.getBlockState(pos.add(-2, 0, 1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(-1, 0, 1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(-2, 0, 1));
        }
        else if ((this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 2)))) && (this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 2)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, 1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 2)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 2)))) && NewSurround.mc.world.getBlockState(pos.add(-1, 0, 2)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(-1, 0, 1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(-1, 0, 2));
        }
        else if ((this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, 1)))) && (this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, 1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, 1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, 1)))) && NewSurround.mc.world.getBlockState(pos.add(2, 0, 1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(1, 0, 1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(2, 0, 1));
        }
        else if ((this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 2)))) && (this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 2)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, 1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 2)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 2)))) && NewSurround.mc.world.getBlockState(pos.add(1, 0, 2)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(1, 0, 1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(1, 0, 2));
        }
        else if ((this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, -2)))) && (this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, -1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, -2)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, -1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, -2)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, -2)))) && NewSurround.mc.world.getBlockState(pos.add(-1, 0, -2)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(-1, 0, -1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(-1, 0, -2));
        }
        else if ((this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, -1)))) && (this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, -1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, -1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, -1, -1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, -1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, -1)))) && NewSurround.mc.world.getBlockState(pos.add(-2, 0, -1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(-1, 0, -1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(-2, 0, -1));
        }
        else if ((this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, -1)))) && (this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, -1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, -1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, -1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, -1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, -1)))) && NewSurround.mc.world.getBlockState(pos.add(2, 0, -1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(1, 0, -1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(2, 0, -1));
        }
        else if ((this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, -2)))) && (this.CrystalPos == null || !new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, -1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, -2)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, -1, -1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, -2)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, -2)))) && NewSurround.mc.world.getBlockState(pos.add(1, 0, -2)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(1, 0, -1)).getBlock() == Blocks.AIR) {
            this.perform(pos.add(1, 0, -2));
        }
        else if (this.checkCrystal(EntityUtil.getVarOffsets(-3, 0, 0)) == null && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-3, 0, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-3, -1, 0)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-3, 0, 0)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-3, 0, 0)))) && NewSurround.mc.world.getBlockState(pos.add(-3, 0, 0)).getBlock() == Blocks.AIR && ((InstantMine.breakPos != null && new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, 0)))) || (BreakCheck.Instance().BrokenPos != null && new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-2, 0, 0)))))) {
            this.perform(pos.add(-3, 0, 0));
        }
        else if (this.checkCrystal(EntityUtil.getVarOffsets(3, 0, 0)) == null && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(3, 0, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(3, -1, 0)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(3, 0, 0)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(3, 0, 0)))) && NewSurround.mc.world.getBlockState(pos.add(3, 0, 0)).getBlock() == Blocks.AIR && ((InstantMine.breakPos != null && new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, 0)))) || (BreakCheck.Instance().BrokenPos != null && new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(2, 0, 0)))))) {
            this.perform(pos.add(3, 0, 0));
        }
        else if (this.checkCrystal(EntityUtil.getVarOffsets(0, 0, 3)) == null && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 3)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, 3)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 3)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 3)))) && NewSurround.mc.world.getBlockState(pos.add(0, 0, 3)).getBlock() == Blocks.AIR && ((InstantMine.breakPos != null && new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 2)))) || (BreakCheck.Instance().BrokenPos != null && new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 2)))))) {
            this.perform(pos.add(0, 0, 3));
        }
        else if (this.checkCrystal(EntityUtil.getVarOffsets(0, 0, -3)) == null && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -3)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, -1, -3)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -3)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -3)))) && NewSurround.mc.world.getBlockState(pos.add(0, 0, -3)).getBlock() == Blocks.AIR && ((InstantMine.breakPos != null && new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -2)))) || (BreakCheck.Instance().BrokenPos != null && new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -2)))))) {
            this.perform(pos.add(0, 0, -3));
        }
        if (this.CrystalPos != null) {
            if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, 1)))) {
                AttackCrystal(pos.add(1, 1, 1));
                if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, 1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, 1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, 1)))) && NewSurround.mc.world.getBlockState(pos.add(1, 1, 1)).getBlock() == Blocks.AIR) {
                    this.perform(pos.add(1, 1, 1));
                }
                else if ((BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 2, 1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 2, 1)))) && NewSurround.mc.world.getBlockState(pos.add(1, 1, 1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(1, 2, 1)).getBlock() == Blocks.AIR) {
                    this.perform(pos.add(1, 2, 1));
                }
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, -1)))) {
                AttackCrystal(pos.add(1, 1, -1));
                if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, -1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, -1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, -1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, -1)))) && NewSurround.mc.world.getBlockState(pos.add(1, 1, -1)).getBlock() == Blocks.AIR) {
                    this.perform(pos.add(1, 1, -1));
                }
                else if ((BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 2, -1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 2, -1)))) && NewSurround.mc.world.getBlockState(pos.add(1, 1, -1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(1, 2, -1)).getBlock() == Blocks.AIR) {
                    this.perform(pos.add(1, 2, -1));
                }
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, -1)))) {
                AttackCrystal(pos.add(-1, 1, -1));
                if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, -1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, -1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, -1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, -1)))) && NewSurround.mc.world.getBlockState(pos.add(-1, 1, -1)).getBlock() == Blocks.AIR) {
                    this.perform(pos.add(-1, 1, -1));
                }
                else if ((BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 2, -1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 2, -1)))) && NewSurround.mc.world.getBlockState(pos.add(-1, 1, -1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(-1, 2, -1)).getBlock() == Blocks.AIR) {
                    this.perform(pos.add(-1, 2, -1));
                }
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, 1)))) {
                AttackCrystal(pos.add(-1, 1, 1));
                if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, 1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, 1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, 1)))) && NewSurround.mc.world.getBlockState(pos.add(-1, 1, 1)).getBlock() == Blocks.AIR) {
                    this.perform(pos.add(-1, 1, 1));
                }
                else if ((BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 2, 1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 2, 1)))) && NewSurround.mc.world.getBlockState(pos.add(-1, 1, 1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(-1, 2, 1)).getBlock() == Blocks.AIR) {
                    this.perform(pos.add(-1, 2, 1));
                }
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, 1)))) {
                AttackCrystal(pos.add(0, 1, 1));
                if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, 1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, 1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, 1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, 1)))) && NewSurround.mc.world.getBlockState(pos.add(0, 1, 1)).getBlock() == Blocks.AIR) {
                    this.perform(pos.add(0, 1, 1));
                }
                else if ((BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 2, 1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 2, 1)))) && NewSurround.mc.world.getBlockState(pos.add(0, 1, 1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(0, 2, 1)).getBlock() == Blocks.AIR) {
                    this.perform(pos.add(0, 2, 1));
                }
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, -1)))) {
                AttackCrystal(pos.add(0, 1, -1));
                if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, -1)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 0, -1)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, -1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 1, -1)))) && NewSurround.mc.world.getBlockState(pos.add(0, 1, -1)).getBlock() == Blocks.AIR) {
                    this.perform(pos.add(0, 1, -1));
                }
                else if ((BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 2, -1)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(0, 2, -1)))) && NewSurround.mc.world.getBlockState(pos.add(0, 1, -1)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(0, 2, -1)).getBlock() == Blocks.AIR) {
                    this.perform(pos.add(0, 2, -1));
                }
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, 0)))) {
                AttackCrystal(pos.add(1, 1, 0));
                if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 0, 0)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, 0)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 1, 0)))) && NewSurround.mc.world.getBlockState(pos.add(1, 1, 0)).getBlock() == Blocks.AIR) {
                    this.perform(pos.add(1, 1, 0));
                }
                else if ((BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 2, 0)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(1, 2, 0)))) && NewSurround.mc.world.getBlockState(pos.add(1, 1, 0)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(-1, 2, 0)).getBlock() == Blocks.AIR) {
                    this.perform(pos.add(1, 2, 0));
                }
            }
            else if (new BlockPos((Vec3i)this.CrystalPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, 0)))) {
                AttackCrystal(pos.add(-1, 1, 0));
                if ((this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, 0)))) && (this.FeetPos == null || !new BlockPos((Vec3i)this.FeetPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 0, 0)))) && (BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, 0)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 1, 0)))) && NewSurround.mc.world.getBlockState(pos.add(-1, 1, 0)).getBlock() == Blocks.AIR) {
                    this.perform(pos.add(-1, 1, 0));
                }
                else if ((BreakCheck.Instance().BrokenPos == null || !new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 2, 0)))) && (InstantMine.breakPos == null || !new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos.add(-1, 2, 0)))) && NewSurround.mc.world.getBlockState(pos.add(-1, 1, 0)).getBlock() == Blocks.AIR && NewSurround.mc.world.getBlockState(pos.add(-1, 2, 0)).getBlock() == Blocks.AIR) {
                    this.perform(pos.add(-1, 2, 0));
                }
            }
        }
    }
    
    public static void AttackCrystal(final BlockPos pos) {
        for (final Entity crystal : (List)NewSurround.mc.world.loadedEntityList.stream().filter(e -> e instanceof EntityEnderCrystal && !e.isDead).sorted(Comparator.comparing(e -> NewSurround.mc.player.getDistance(e))).collect(Collectors.toList())) {
            if (crystal instanceof EntityEnderCrystal) {
                if (crystal.getDistanceSq(pos) > 1.0) {
                    continue;
                }
                NewSurround.mc.player.connection.sendPacket((Packet)new CPacketUseEntity(crystal));
                NewSurround.mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.MAIN_HAND));
            }
        }
    }
    
    private Entity getEndCrystal() {
        Entity crystal = null;
        for (final Entity player : NewSurround.mc.world.loadedEntityList) {
            if (!(player instanceof EntityEnderCrystal)) {
                continue;
            }
            crystal = player;
        }
        return crystal;
    }
    
    private void perform(final BlockPos pos) {
        final int old = NewSurround.mc.player.inventory.currentItem;
        if (InventoryUtil.findHotbarBlock(BlockObsidian.class) == -1) {
            return;
        }
        NewSurround.mc.player.inventory.currentItem = InventoryUtil.findHotbarBlock(BlockObsidian.class);
        NewSurround.mc.playerController.updateController();
        BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
        NewSurround.mc.player.inventory.currentItem = old;
        NewSurround.mc.playerController.updateController();
    }
    
    Entity checkCrystal(final Vec3d[] list) {
        Entity crystal = null;
        for (final Vec3d vec3d : list) {
            final BlockPos position = new BlockPos(NewSurround.mc.player.getPositionVector()).add(vec3d.x, vec3d.y, vec3d.z);
            for (final Entity entity : AntiCev.mc.world.getEntitiesWithinAABB((Class)Entity.class, new AxisAlignedBB(position))) {
                if (entity instanceof EntityEnderCrystal) {
                    if (crystal != null) {
                        continue;
                    }
                    crystal = entity;
                }
            }
        }
        return crystal;
    }
    
    private EntityPlayer getTarget() {
        EntityPlayer target = null;
        double distance = 12.0;
        for (final EntityPlayer player : NewSurround.mc.world.playerEntities) {
            if (!EntityUtil.isntValid((Entity)player, 12.0) && !AbyssHack.friendManager.isFriend(player.getName())) {
                if (NewSurround.mc.player.posY - player.posY >= 5.0) {
                    continue;
                }
                if (target == null) {
                    target = player;
                    distance = EntityUtil.mc.player.getDistanceSq((Entity)player);
                }
                else {
                    if (EntityUtil.mc.player.getDistanceSq((Entity)player) >= distance) {
                        continue;
                    }
                    target = player;
                    distance = EntityUtil.mc.player.getDistanceSq((Entity)player);
                }
            }
        }
        return target;
    }
}
