//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.features.modules.combat;

import dev.hanfeng.cnmm.features.modules.*;
import dev.hanfeng.cnmm.features.setting.*;
import net.minecraft.entity.player.*;
import dev.hanfeng.cnmm.*;
import dev.hanfeng.cnmm.event.events.*;
import net.minecraft.util.math.*;
import java.awt.*;
import net.minecraft.init.*;
import net.minecraft.item.*;
import net.minecraft.block.*;
import dev.hanfeng.cnmm.features.command.*;
import net.minecraft.entity.*;
import dev.hanfeng.cnmm.util.*;
import java.util.*;
import net.minecraft.util.*;
import net.minecraft.entity.projectile.*;
import net.minecraft.entity.item.*;

public class AutoHoleKick extends Module
{
    private final Setting<page> pageSetting;
    private final Setting<Integer> renderTime;
    private final Setting<Boolean> render;
    private final Setting<Integer> colorR;
    private final Setting<Integer> colorG;
    private final Setting<Integer> colorB;
    private final Setting<Integer> colorA;
    private final Setting<Double> renderSpeed;
    private final Setting<Boolean> renderText;
    private final Setting<Float> targetRange;
    private final Setting<Double> maxTargetSpeed;
    private final Setting<surCheckMode> surCheck;
    private final Setting<Boolean> burCheck;
    private final Setting<Bind> forcePlaceBind;
    private final Setting<Integer> minArmorPieces;
    private final Setting<Integer> delay;
    private final Setting<Double> circulateDelay;
    private final Setting<Double> mineDelay;
    private final Setting<FeetPlaceMode> feetPlace;
    private final Setting<Double> placeRange;
    private final Setting<Double> minRange;
    private final Setting<Boolean> noOutOfDistancePlace;
    private final Setting<Boolean> checkPlaceable;
    private final Setting<Boolean> farPlace;
    private final Setting<Boolean> noPlacePisOnBreakPos;
    private final Setting<Boolean> noPlaceRstOnBreakPos;
    private final Setting<Integer> advanceMine;
    private final Setting<Boolean> attackCry;
    private final Setting<Integer> attackRange;
    private final Setting<Integer> noSuicide;
    private final Setting<Boolean> disableOnNoBlock;
    private final Setting<Boolean> onGroundCheck;
    private final Setting<Integer> count;
    private final Setting<Boolean> speedCheck;
    private final Setting<Double> maxSpeed;
    private final Setting<Boolean> noPushSelf;
    Timer mineTimer;
    Timer timer;
    BlockPos piston;
    BlockPos rst;
    int stage;
    int ct;
    int ct1;
    EntityPlayer target;
    private BlockPos renderPos;
    Timer dynamicRenderingTimer;
    double renderCount;
    Timer renderTimer;
    Timer circulateTimer;
    boolean canRender;
    static int rotate;
    
    public AutoHoleKick() {
        super("AutoHoleKick", "AutoKick", Category.COMBAT, true, false, false);
        this.pageSetting = (Setting<page>)this.register(new Setting("page", (T)page.render));
        this.renderTime = (Setting<Integer>)this.register(new Setting("RenderTime", (T)200, (T)0, (T)1000, v -> this.pageSetting.getValue() == page.render));
        this.render = (Setting<Boolean>)this.register(new Setting("render", (T)true, v -> this.pageSetting.getValue() == page.render));
        this.colorR = (Setting<Integer>)this.register(new Setting("R", (T)232, (T)0, (T)255, v -> this.render.getValue() && this.pageSetting.getValue() == page.render));
        this.colorG = (Setting<Integer>)this.register(new Setting("G", (T)226, (T)0, (T)255, v -> this.render.getValue() && this.pageSetting.getValue() == page.render));
        this.colorB = (Setting<Integer>)this.register(new Setting("B", (T)2, (T)0, (T)255, v -> this.render.getValue() && this.pageSetting.getValue() == page.render));
        this.colorA = (Setting<Integer>)this.register(new Setting("Alpha", (T)100, (T)0, (T)255, v -> this.render.getValue() && this.pageSetting.getValue() == page.render));
        this.renderSpeed = (Setting<Double>)this.register(new Setting("RenderSpeed", (T)5.0, (T)0.0, (T)10.0, v -> this.pageSetting.getValue() == page.render));
        this.renderText = (Setting<Boolean>)this.register(new Setting("RenderText", (T)true, v -> this.pageSetting.getValue() == page.render));
        this.targetRange = (Setting<Float>)this.register(new Setting("TargetRange", (T)4.0f, (T)1.0f, (T)6.0f, v -> this.pageSetting.getValue() == page.target));
        this.maxTargetSpeed = (Setting<Double>)this.register(new Setting("MaxTargetSpeed", (T)4.0, (T)0.0, (T)15.0, v -> this.pageSetting.getValue() == page.target));
        this.surCheck = (Setting<surCheckMode>)this.register(new Setting("OnlyPushSurrounded", (T)surCheckMode.normal, v -> this.pageSetting.getValue() == page.target));
        this.burCheck = (Setting<Boolean>)this.register(new Setting("NoPushNotHaveFeet", (T)true, v -> this.pageSetting.getValue() == page.target));
        this.forcePlaceBind = (Setting<Bind>)this.register(new Setting("ForcePlace", (T)new Bind(0), v -> this.pageSetting.getValue() == page.target && this.surCheck.getValue() != surCheckMode.off));
        this.minArmorPieces = (Setting<Integer>)this.register(new Setting("MinArmorPieces", (T)3, (T)0, (T)4, v -> this.pageSetting.getValue() == page.target));
        this.delay = (Setting<Integer>)this.register(new Setting("Delay", (T)200, (T)0, (T)1000, v -> this.pageSetting.getValue() == page.place));
        this.circulateDelay = (Setting<Double>)this.register(new Setting("circulateDelay", (T)0.0, (T)0.0, (T)200.0, v -> this.pageSetting.getValue() == page.place));
        this.mineDelay = (Setting<Double>)this.register(new Setting("mineDelay", (T)20.0, (T)0.0, (T)400.0, v -> this.pageSetting.getValue() == page.place));
        this.feetPlace = (Setting<FeetPlaceMode>)this.register(new Setting("FeetPlace", (T)FeetPlaceMode.Obsidian, v -> this.pageSetting.getValue() == page.place));
        this.placeRange = (Setting<Double>)this.register(new Setting("PlaceRange", (T)5.0, (T)0.0, (T)6.0, v -> this.pageSetting.getValue() == page.place));
        this.minRange = (Setting<Double>)this.register(new Setting("AntiStickRange", (T)2.6, (T)0.0, (T)4.0, v -> this.pageSetting.getValue() == page.place));
        this.noOutOfDistancePlace = (Setting<Boolean>)this.register(new Setting("NoOutOfDistancePlace", (T)true, v -> this.pageSetting.getValue() == page.place));
        this.checkPlaceable = (Setting<Boolean>)this.register(new Setting("CheckPlaceable", (T)false, v -> this.pageSetting.getValue() == page.place));
        this.farPlace = (Setting<Boolean>)this.register(new Setting("FarPlace", (T)false, v -> this.pageSetting.getValue() == page.place));
        this.noPlacePisOnBreakPos = (Setting<Boolean>)this.register(new Setting("NoPlacePisOnBreakPos", (T)true, v -> this.pageSetting.getValue() == page.place));
        this.noPlaceRstOnBreakPos = (Setting<Boolean>)this.register(new Setting("NoPlaceRstOnBreakPos", (T)true, v -> this.pageSetting.getValue() == page.place));
        this.advanceMine = (Setting<Integer>)this.register(new Setting("AdvanceMineOnStage", (T)2, (T)0, (T)3, v -> this.pageSetting.getValue() == page.place));
        this.attackCry = (Setting<Boolean>)this.register(new Setting("AttackCrystal", (T)true, v -> this.pageSetting.getValue() == page.breakCry));
        this.attackRange = (Setting<Integer>)this.register(new Setting("AttackCryRange", (T)5, (T)0, (T)7, v -> this.attackCry.getValue() && this.pageSetting.getValue() == page.breakCry));
        this.noSuicide = (Setting<Integer>)this.register(new Setting("NoSuicideHealth", (T)5, (T)0, (T)20, v -> this.attackCry.getValue() && this.pageSetting.getValue() == page.breakCry));
        this.disableOnNoBlock = (Setting<Boolean>)this.register(new Setting("DisableOnNoBlock", (T)true, v -> this.pageSetting.getValue() == page.selfCheck));
        this.onGroundCheck = (Setting<Boolean>)this.register(new Setting("OnGroundCheck", (T)true, v -> this.pageSetting.getValue() == page.selfCheck));
        this.count = (Setting<Integer>)this.register(new Setting("AntiStickCount", (T)20, (T)0, (T)200, v -> this.pageSetting.getValue() == page.selfCheck));
        this.speedCheck = (Setting<Boolean>)this.register(new Setting("SpeedCheck", (T)true, v -> this.pageSetting.getValue() == page.selfCheck));
        this.maxSpeed = (Setting<Double>)this.register(new Setting("SelfMaxSpeed", (T)4.0, (T)0.0, (T)20.0, v -> this.speedCheck.getValue() && this.pageSetting.getValue() == page.selfCheck));
        this.noPushSelf = (Setting<Boolean>)this.register(new Setting("NoPushSelf", (T)true, v -> this.pageSetting.getValue() == page.selfCheck));
        this.mineTimer = new Timer();
        this.timer = new Timer();
        this.stage = 0;
        this.ct = 0;
        this.ct1 = 0;
        this.dynamicRenderingTimer = new Timer();
        this.renderTimer = new Timer();
        this.circulateTimer = new Timer();
        this.canRender = false;
    }
    
    @Override
    public void onEnable() {
        this.piston = null;
        this.rst = null;
        this.target = null;
        this.renderPos = null;
        this.stage = 0;
        this.ct = 0;
        this.ct1 = 0;
        this.circulateTimer.setMs(10000L);
        if (!AbyssHack.moduleManager.isModuleEnabled("Protent")) {
            AbyssHack.moduleManager.enableModule("Protent");
        }
        else if (AbyssHack.moduleManager.isModuleEnabled("Protent")) {
            AbyssHack.moduleManager.disableModule("Protent");
        }
    }
    
    @Override
    public void onRender3D(final Render3DEvent event) {
        if (this.piston != null) {
            this.renderPos = this.piston;
        }
        if (this.renderPos != null) {
            if (this.canRender) {
                if (this.renderCount / 100.0 < 0.5 && this.dynamicRenderingTimer.passedDms(0.5)) {
                    this.renderCount += this.renderSpeed.getValue();
                    this.dynamicRenderingTimer.reset();
                }
                final AxisAlignedBB axisAlignedBB = new AxisAlignedBB(this.renderPos.getX() + 0.5 - this.renderCount / 100.0, this.renderPos.getY() + 0.5 - this.renderCount / 100.0, this.renderPos.getZ() + 0.5 - this.renderCount / 100.0, this.renderPos.getX() + 0.5 + this.renderCount / 100.0, this.renderPos.getY() + 0.5 + this.renderCount / 100.0, this.renderPos.getZ() + 0.5 + this.renderCount / 100.0);
                if (this.render.getValue()) {
                    RenderUtil.drawBBFill(axisAlignedBB, new Color(this.colorR.getValue(), this.colorG.getValue(), this.colorB.getValue()), this.colorA.getValue());
                }
                if (this.renderText.getValue()) {
                    RenderUtil.drawText(this.renderPos, "OMG He Pushed!");
                }
            }
            else {
                this.renderCount = 0.0;
            }
        }
    }
    
    @Override
    public void onUpdate() {
        if (this.circulateTimer.passedDms(this.circulateDelay.getValue())) {
            if (this.renderTimer.passedDms(this.renderTime.getValue())) {
                this.canRender = false;
            }
            final int oldSlot = AutoHoleKick.mc.player.inventory.currentItem;
            final int obbySlot = InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.OBSIDIAN));
            int pisSlot = InventoryUtil.getItemHotbar(Item.getItemFromBlock((Block)Blocks.PISTON));
            if (pisSlot == -1) {
                pisSlot = InventoryUtil.getItemHotbar(Item.getItemFromBlock((Block)Blocks.STICKY_PISTON));
                if (pisSlot == -1) {
                    if (this.disableOnNoBlock.getValue()) {
                        Command.sendMessage("NoPiston");
                        this.disable();
                    }
                    return;
                }
            }
            final int rstSlot = InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.REDSTONE_BLOCK));
            if (rstSlot == -1) {
                if (this.disableOnNoBlock.getValue()) {
                    Command.sendMessage("NoRedStoneBlock");
                    this.disable();
                }
            }
            else {
                if (this.stage == 0) {
                    if (!this.timer.passedDms(this.delay.getValue())) {
                        return;
                    }
                    final EntityPlayer target = this.getTarget(this.targetRange.getValue());
                    this.target = target;
                    this.piston = this.getPistonPos(target);
                    if (this.piston == null) {
                        return;
                    }
                    this.rst = this.getRSTPos(this.piston, false, this.noPlaceRstOnBreakPos.getValue());
                    if (this.rst == null) {
                        return;
                    }
                    this.ct = 0;
                    this.ct1 = 0;
                    ++this.stage;
                }
                if (this.stage == 1) {
                    if (!this.timer.passedDms(this.delay.getValue())) {
                        return;
                    }
                    this.timer.reset();
                    if (this.attackCry.getValue()) {
                        this.attackCrystal();
                    }
                    if (this.feetPlace.getValue().equals(FeetPlaceMode.RedStone) && AutoHoleKick.mc.world.getBlockState(this.piston.add(0, -1, 0)).getBlock().equals(Blocks.AIR) && isNoBBoxBlocked(this.piston.add(0, -1, 0))) {
                        if (this.noOutOfDistancePlace.getValue() && Math.sqrt(AutoHoleKick.mc.player.getDistanceSq(this.piston.add(0, -1, 0))) > this.placeRange.getValue()) {
                            this.stage = 0;
                            return;
                        }
                        InventoryUtil.switchToHotbarSlot(rstSlot, false);
                        BlockUtil.placeBlock(this.piston.add(0, -1, 0), EnumHand.MAIN_HAND, false, true, true);
                        InventoryUtil.switchToHotbarSlot(oldSlot, false);
                    }
                    if (this.feetPlace.getValue().equals(FeetPlaceMode.Obsidian) && AutoHoleKick.mc.world.getBlockState(this.piston.add(0, -1, 0)).getBlock().equals(Blocks.AIR) && isNoBBoxBlocked(this.piston.add(0, -1, 0))) {
                        if (obbySlot == -1) {
                            this.stage = 2;
                            return;
                        }
                        if (this.noOutOfDistancePlace.getValue() && Math.sqrt(AutoHoleKick.mc.player.getDistanceSq(this.piston.add(0, -1, 0))) > this.placeRange.getValue()) {
                            this.stage = 0;
                            return;
                        }
                        InventoryUtil.switchToHotbarSlot(obbySlot, false);
                        BlockUtil.placeBlock(this.piston.add(0, -1, 0), EnumHand.MAIN_HAND, false, true, true);
                        InventoryUtil.switchToHotbarSlot(oldSlot, false);
                    }
                    if (this.advanceMine.getValue() == 1) {
                        mineRst(this.target, this.piston);
                    }
                    ++this.stage;
                }
                if (this.stage == 2) {
                    if (!this.timer.passedDms(this.delay.getValue())) {
                        return;
                    }
                    this.timer.reset();
                    this.canRender = true;
                    this.renderTimer.reset();
                    if (!AutoHoleKick.mc.world.getBlockState(this.piston).getBlock().equals(Blocks.AIR) && !AutoHoleKick.mc.world.getBlockState(this.piston).getBlock().equals(Blocks.PISTON) && !AutoHoleKick.mc.world.getBlockState(this.piston).getBlock().equals(Blocks.STICKY_PISTON)) {
                        this.stage = 0;
                        return;
                    }
                    if (this.noOutOfDistancePlace.getValue() && Math.sqrt(AutoHoleKick.mc.player.getDistanceSq(this.piston)) > this.placeRange.getValue()) {
                        this.stage = 0;
                        return;
                    }
                    InventoryUtil.switchToHotbarSlot(pisSlot, false);
                    RotationUtil.faceYawAndPitch((float)AutoHoleKick.rotate, 0.0f);
                    BlockUtil.placeBlock(this.piston, EnumHand.MAIN_HAND, false, true, true);
                    InventoryUtil.switchToHotbarSlot(oldSlot, false);
                    if ((AutoHoleKick.mc.world.getBlockState(this.piston).getBlock().equals(Blocks.PISTON) || !this.checkPlaceable.getValue()) && isNoBBoxBlocked(this.piston)) {
                        ++this.stage;
                        if (this.advanceMine.getValue() == 2) {
                            mineRst(this.target, this.piston);
                        }
                    }
                    else {
                        ++this.ct1;
                        if (this.ct1 > this.count.getValue()) {
                            this.stage = 0;
                        }
                    }
                }
                if (this.stage == 3) {
                    if (BlockUtil.haveNeighborBlock(this.piston, Blocks.REDSTONE_BLOCK).size() > 0) {
                        this.mineTimer.reset();
                        this.stage = 4;
                        return;
                    }
                    if (!isNoBBoxBlocked(this.rst) || (this.checkPlaceable.getValue() && !AutoHoleKick.mc.world.getBlockState(this.piston).getBlock().equals(Blocks.PISTON) && !AutoHoleKick.mc.world.getBlockState(this.piston).getBlock().equals(Blocks.STICKY_PISTON))) {
                        this.stage = 0;
                    }
                    else {
                        if (!AutoHoleKick.mc.world.getBlockState(this.rst).getBlock().equals(Blocks.AIR) && !AutoHoleKick.mc.world.getBlockState(this.rst).getBlock().equals(Blocks.REDSTONE_BLOCK)) {
                            this.stage = 0;
                            return;
                        }
                        InventoryUtil.switchToHotbarSlot(rstSlot, false);
                        BlockUtil.placeBlock(this.rst, EnumHand.MAIN_HAND, false, true, true);
                        InventoryUtil.switchToHotbarSlot(oldSlot, false);
                        if (AutoHoleKick.mc.world.getBlockState(this.rst).getBlock().equals(Blocks.REDSTONE_BLOCK)) {
                            this.mineTimer.reset();
                            this.stage = 4;
                            if (this.advanceMine.getValue() == 3) {
                                mineRst(this.target, this.piston);
                            }
                        }
                        ++this.ct;
                        if (this.ct > this.count.getValue()) {
                            this.stage = 0;
                        }
                    }
                }
                if (this.stage == 4) {
                    if (!this.mineTimer.passedDms(this.mineDelay.getValue())) {
                        return;
                    }
                    mineRst(this.target, this.piston);
                    this.stage = 0;
                }
                this.circulateTimer.reset();
            }
        }
    }
    
    public static void mineRst(final EntityPlayer target, final BlockPos piston) {
        if (!AutoHoleKick.mc.world.getBlockState(BlockUtil.getFlooredPosition((Entity)target)).getBlock().equals(Blocks.AIR) && AutoHoleKick.mc.world.getBlockState(BlockUtil.getFlooredPosition((Entity)target).add(0, 2, 0)).getBlock().equals(Blocks.AIR) && !AutoHoleKick.mc.world.getBlockState(piston.add(0, -1, 0)).getBlock().equals(Blocks.AIR)) {
            if (AutoHoleKick.mc.world.getBlockState(piston.add(0, 1, 0)).getBlock().equals(Blocks.AIR)) {
                if (BlockUtil.haveNeighborBlock(piston, Blocks.REDSTONE_BLOCK).size() == 1) {
                    final BlockPos minePos = BlockUtil.haveNeighborBlock(piston, Blocks.REDSTONE_BLOCK).get(0);
                    if (minePos != null && (InstantMine.breakPos == null || !InstantMine.breakPos.equals((Object)minePos))) {
                        AutoHoleKick.mc.playerController.onPlayerDamageBlock(minePos, BlockUtil.getRayTraceFacing(minePos));
                    }
                }
            }
            else if (AutoHoleKick.mc.world.getBlockState(piston.add(0, 1, 0)).getBlock().equals(Blocks.REDSTONE_BLOCK) && BlockUtil.haveNeighborBlock(piston, Blocks.REDSTONE_BLOCK).size() == 1 && (InstantMine.breakPos == null || !InstantMine.breakPos.equals((Object)piston.add(0, 1, 0)))) {
                AutoHoleKick.mc.playerController.onPlayerDamageBlock(piston.add(0, 1, 0), BlockUtil.getRayTraceFacing(piston.add(0, 1, 0)));
            }
        }
    }
    
    public boolean isSur(final Entity player, final surCheckMode checkMode) {
        final BlockPos playerPos = BlockUtil.getFlooredPosition(player);
        if (checkMode == surCheckMode.normal && !AutoHoleKick.mc.world.getBlockState(playerPos.add(1, 0, 0)).getBlock().equals(Blocks.AIR) && !AutoHoleKick.mc.world.getBlockState(playerPos.add(-1, 0, 0)).getBlock().equals(Blocks.AIR) && !AutoHoleKick.mc.world.getBlockState(playerPos.add(0, 0, 1)).getBlock().equals(Blocks.AIR) && !AutoHoleKick.mc.world.getBlockState(playerPos.add(0, 0, -1)).getBlock().equals(Blocks.AIR)) {
            return true;
        }
        if (checkMode == surCheckMode.center) {
            final double x = Math.abs(player.posX) - Math.floor(Math.abs(player.posX));
            final double z = Math.abs(player.posZ) - Math.floor(Math.abs(player.posZ));
            if (x <= 0.7 && x >= 0.3 && z <= 0.7 && z >= 0.3) {
                return true;
            }
        }
        return checkMode == surCheckMode.off;
    }
    
    public boolean helpingBlockCheck(final BlockPos pos) {
        return !AutoHoleKick.mc.world.getBlockState(pos.add(1, 0, 0)).getBlock().equals(Blocks.AIR) || !AutoHoleKick.mc.world.getBlockState(pos.add(-1, 0, 0)).getBlock().equals(Blocks.AIR) || !AutoHoleKick.mc.world.getBlockState(pos.add(0, 1, 0)).getBlock().equals(Blocks.AIR) || !AutoHoleKick.mc.world.getBlockState(pos.add(0, -1, 0)).getBlock().equals(Blocks.AIR) || !AutoHoleKick.mc.world.getBlockState(pos.add(0, 0, -1)).getBlock().equals(Blocks.AIR) || !AutoHoleKick.mc.world.getBlockState(pos.add(0, 0, 1)).getBlock().equals(Blocks.AIR);
    }
    
    private EntityPlayer getTarget(final double range) {
        EntityPlayer target = null;
        double distance = range;
        if (this.speedCheck.getValue() && AbyssHack.speedManager.getPlayerSpeed((EntityPlayer)AutoHoleKick.mc.player) > this.maxSpeed.getValue()) {
            return null;
        }
        for (final EntityPlayer player : AutoHoleKick.mc.world.playerEntities) {
            final BlockPos pistonPos = this.getPistonPos(player);
            final BlockPos rstPos = this.getRSTPos(this.getPistonPos(player), false, this.noPlaceRstOnBreakPos.getValue());
            if (!EntityUtil.isntValid((Entity)player, range) && !AbyssHack.friendManager.isFriend(player.getName()) && AbyssHack.speedManager.getPlayerSpeed(player) <= this.maxTargetSpeed.getValue() && pistonPos != null && rstPos != null && TargetUtil.getArmorPieces(player) >= this.minArmorPieces.getValue()) {
                if (this.surCheck.getValue() != surCheckMode.off) {
                    if (!this.forcePlaceBind.getValue().isDown()) {
                        Boolean p = true;
                        if (!this.isSur((Entity)player, this.surCheck.getValue())) {
                            if (this.burCheck.getValue()) {
                                if (AutoHoleKick.mc.world.getBlockState(BlockUtil.getFlooredPosition((Entity)player)).getBlock().equals(Blocks.AIR)) {
                                    continue;
                                }
                                p = false;
                            }
                            if (p) {
                                continue;
                            }
                        }
                    }
                }
                if ((this.noPushSelf.getValue() && BlockUtil.getFlooredPosition((Entity)player).equals((Object)BlockUtil.getFlooredPosition((Entity)AutoHoleKick.mc.player))) || ((AutoHoleKick.mc.player.posY - player.posY <= -1.0 || AutoHoleKick.mc.player.posY - player.posY >= 2.0) && this.distanceToXZ(pistonPos.getX() + 0.5, pistonPos.getZ() + 0.5) < this.minRange.getValue()) || (this.onGroundCheck.getValue() && !AutoHoleKick.mc.player.onGround)) {
                    continue;
                }
                if (target == null) {
                    target = player;
                    distance = EntityUtil.mc.player.getDistanceSq((Entity)player);
                }
                else {
                    if (EntityUtil.mc.player.getDistanceSq((Entity)player) >= distance) {
                        continue;
                    }
                    target = player;
                    distance = EntityUtil.mc.player.getDistanceSq((Entity)player);
                }
            }
        }
        return target;
    }
    
    public double distanceToXZ(final double x, final double z) {
        final double dx = AutoHoleKick.mc.player.posX - x;
        final double dz = AutoHoleKick.mc.player.posZ - z;
        return Math.sqrt(dx * dx + dz * dz);
    }
    
    public void attackCrystal() {
        if (AutoHoleKick.mc.player.getHealth() >= this.noSuicide.getValue()) {
            final ArrayList<Entity> crystalList = new ArrayList<Entity>();
            for (final Entity entity : AutoHoleKick.mc.world.loadedEntityList) {
                if (entity instanceof EntityEnderCrystal) {
                    crystalList.add(entity);
                }
            }
            if (crystalList.size() != 0) {
                final HashMap<Entity, Double> distantMap = new HashMap<Entity, Double>();
                for (final Entity crystal : crystalList) {
                    if (AutoHoleKick.mc.player.getDistance(crystal.posX, crystal.posY, crystal.posZ) < this.attackRange.getValue()) {
                        distantMap.put(crystal, AutoHoleKick.mc.player.getDistance(crystal.posX, crystal.posY, crystal.posZ));
                    }
                }
                final List<Map.Entry<Entity, Double>> list = new ArrayList<Map.Entry<Entity, Double>>(distantMap.entrySet());
                list.sort((Comparator<? super Map.Entry<Entity, Double>>)Map.Entry.comparingByValue());
                if (list.size() != 0 && list.get(0).getValue() < 5.0) {
                    EntityUtil.attackEntity(list.get(list.size() - 1).getKey(), true, true);
                }
            }
        }
    }
    
    public BlockPos getRSTPos(final BlockPos pistonPos, final boolean helpBlockCheck, final boolean instaMineCheck) {
        if (pistonPos == null) {
            return null;
        }
        if (BlockUtil.haveNeighborBlock(pistonPos, Blocks.REDSTONE_BLOCK).size() > 0 && isNoBBoxBlocked(pistonPos)) {
            return BlockUtil.haveNeighborBlock(pistonPos, Blocks.REDSTONE_BLOCK).get(0);
        }
        final ArrayList<BlockPos> placePosList = new ArrayList<BlockPos>();
        placePosList.add(pistonPos.add(0, 1, 0));
        placePosList.add(pistonPos.add(0, -1, 0));
        placePosList.add(pistonPos.add(-1, 0, 0));
        placePosList.add(pistonPos.add(1, 0, 0));
        placePosList.add(pistonPos.add(0, 0, -1));
        placePosList.add(pistonPos.add(0, 0, 1));
        final HashMap<BlockPos, Double> distantMap = new HashMap<BlockPos, Double>();
        for (final BlockPos rSTPos : placePosList) {
            if (AutoHoleKick.mc.world.getBlockState(rSTPos).getBlock().equals(Blocks.AIR) && isNoBBoxBlocked(rSTPos) && (!helpBlockCheck || this.helpingBlockCheck(rSTPos)) && (InstantMine.breakPos == null || !instaMineCheck || !InstantMine.breakPos.equals((Object)rSTPos))) {
                distantMap.put(rSTPos, AutoHoleKick.mc.player.getDistanceSq(rSTPos));
            }
        }
        final List<Map.Entry<BlockPos, Double>> list = new ArrayList<Map.Entry<BlockPos, Double>>(distantMap.entrySet());
        list.sort((Comparator<? super Map.Entry<BlockPos, Double>>)Map.Entry.comparingByValue());
        if (list.size() == 0) {
            return null;
        }
        return list.get(0).getKey();
    }
    
    public BlockPos getRSTPos2(final BlockPos pistonPos) {
        if (pistonPos == null) {
            return null;
        }
        if (BlockUtil.haveNeighborBlock(pistonPos, Blocks.REDSTONE_BLOCK).size() > 0 && isNoBBoxBlocked(pistonPos)) {
            return BlockUtil.haveNeighborBlock(pistonPos, Blocks.REDSTONE_BLOCK).get(0);
        }
        final ArrayList<BlockPos> placePosList = new ArrayList<BlockPos>();
        placePosList.add(pistonPos.add(0, 1, 0));
        placePosList.add(pistonPos.add(-1, 0, 0));
        placePosList.add(pistonPos.add(1, 0, 0));
        placePosList.add(pistonPos.add(0, 0, -1));
        placePosList.add(pistonPos.add(0, 0, 1));
        final HashMap<BlockPos, Double> distantMap = new HashMap<BlockPos, Double>();
        for (final BlockPos rSTPos : placePosList) {
            if (AutoHoleKick.mc.world.getBlockState(rSTPos).getBlock().equals(Blocks.AIR) && isNoBBoxBlocked(rSTPos) && this.helpingBlockCheck(rSTPos)) {
                distantMap.put(rSTPos, AutoHoleKick.mc.player.getDistanceSq(rSTPos));
            }
        }
        final List<Map.Entry<BlockPos, Double>> list = new ArrayList<Map.Entry<BlockPos, Double>>(distantMap.entrySet());
        list.sort((Comparator<? super Map.Entry<BlockPos, Double>>)Map.Entry.comparingByValue());
        if (list.size() == 0) {
            return null;
        }
        return list.get(0).getKey();
    }
    
    public static boolean headCheck(final BlockPos playerPos) {
        return AutoHoleKick.mc.world.getBlockState(playerPos.add(0, 1, 0)).getBlock().equals(Blocks.AIR) && AutoHoleKick.mc.world.getBlockState(playerPos.add(0, 2, 0)).getBlock().equals(Blocks.AIR);
    }
    
    public BlockPos getPistonPos(final EntityPlayer player) {
        if (player == null) {
            return null;
        }
        final BlockPos pPos = BlockUtil.getFlooredPosition((Entity)player);
        if (!AutoHoleKick.mc.world.getBlockState(pPos.add(0, 1, 0)).getBlock().equals(Blocks.AIR)) {
            return null;
        }
        final HashMap<BlockPos, Double> distantMap = new HashMap<BlockPos, Double>();
        if (((!AutoHoleKick.mc.world.getBlockState(pPos.add(1, 1, 0)).getBlock().equals(Blocks.AIR) || !isNoBBoxBlocked(pPos.add(1, 1, 0))) && (!AutoHoleKick.mc.world.getBlockState(pPos.add(1, 1, 0)).getBlock().equals(Blocks.PISTON) || !BlockUtil.isFacing(pPos.add(1, 1, 0), EnumFacing.WEST))) || !AutoHoleKick.mc.world.getBlockState(pPos.add(-1, 1, 0)).getBlock().equals(Blocks.AIR) || ((!headCheck(pPos) || !AutoHoleKick.mc.world.getBlockState(pPos.add(-1, 2, 0)).getBlock().equals(Blocks.AIR)) && !AutoHoleKick.mc.world.getBlockState(pPos.add(-1, 0, 0)).getBlock().equals(Blocks.AIR))) {
            if (((AutoHoleKick.mc.world.getBlockState(pPos.add(1, 1, 0)).getBlock().equals(Blocks.AIR) && isNoBBoxBlocked(pPos.add(1, 1, 0))) || (AutoHoleKick.mc.world.getBlockState(pPos.add(1, 1, 0)).getBlock().equals(Blocks.PISTON) && BlockUtil.isFacing(pPos.add(1, 1, 0), EnumFacing.WEST))) && !AutoHoleKick.mc.world.getBlockState(pPos.add(1, 0, 0)).getBlock().equals(Blocks.AIR) && !AutoHoleKick.mc.world.getBlockState(pPos.add(1, 0, 0)).getBlock().equals(Blocks.REDSTONE_BLOCK) && !AutoHoleKick.mc.world.getBlockState(pPos).getBlock().equals(Blocks.AIR) && AutoHoleKick.mc.world.getBlockState(pPos.add(1, 2, 0)).getBlock().equals(Blocks.AIR) && AutoHoleKick.mc.world.getBlockState(pPos.add(0, 2, 0)).getBlock().equals(Blocks.AIR)) {
                distantMap.put(pPos.add(1, 1, 0), AutoHoleKick.mc.player.getDistance((double)pPos.add(1, 1, 0).getX(), (double)pPos.add(1, 1, 0).getY(), (double)pPos.add(1, 1, 0).getZ()));
            }
        }
        else {
            distantMap.put(pPos.add(1, 1, 0), AutoHoleKick.mc.player.getDistance((double)pPos.add(1, 1, 0).getX(), (double)pPos.add(1, 1, 0).getY(), (double)pPos.add(1, 1, 0).getZ()));
        }
        if (((!AutoHoleKick.mc.world.getBlockState(pPos.add(-1, 1, 0)).getBlock().equals(Blocks.AIR) || !isNoBBoxBlocked(pPos.add(-1, 1, 0))) && (!AutoHoleKick.mc.world.getBlockState(pPos.add(-1, 1, 0)).getBlock().equals(Blocks.PISTON) || !BlockUtil.isFacing(pPos.add(-1, 1, 0), EnumFacing.EAST))) || !AutoHoleKick.mc.world.getBlockState(pPos.add(1, 1, 0)).getBlock().equals(Blocks.AIR) || ((!headCheck(pPos) || !AutoHoleKick.mc.world.getBlockState(pPos.add(1, 2, 0)).getBlock().equals(Blocks.AIR)) && !AutoHoleKick.mc.world.getBlockState(pPos.add(1, 0, 0)).getBlock().equals(Blocks.AIR))) {
            if (((AutoHoleKick.mc.world.getBlockState(pPos.add(-1, 1, 0)).getBlock().equals(Blocks.AIR) && isNoBBoxBlocked(pPos.add(-1, 1, 0))) || (AutoHoleKick.mc.world.getBlockState(pPos.add(-1, 1, 0)).getBlock().equals(Blocks.PISTON) && BlockUtil.isFacing(pPos.add(-1, 1, 0), EnumFacing.EAST))) && !AutoHoleKick.mc.world.getBlockState(pPos.add(-1, 0, 0)).getBlock().equals(Blocks.AIR) && !AutoHoleKick.mc.world.getBlockState(pPos.add(-1, 0, 0)).getBlock().equals(Blocks.REDSTONE_BLOCK) && !AutoHoleKick.mc.world.getBlockState(pPos).getBlock().equals(Blocks.AIR) && AutoHoleKick.mc.world.getBlockState(pPos.add(-1, 2, 0)).getBlock().equals(Blocks.AIR) && AutoHoleKick.mc.world.getBlockState(pPos.add(0, 2, 0)).getBlock().equals(Blocks.AIR)) {
                distantMap.put(pPos.add(-1, 1, 0), AutoHoleKick.mc.player.getDistance((double)pPos.add(-1, 1, 0).getX(), (double)pPos.add(-1, 1, 0).getY(), (double)pPos.add(-1, 1, 0).getZ()));
            }
        }
        else {
            distantMap.put(pPos.add(-1, 1, 0), AutoHoleKick.mc.player.getDistance((double)pPos.add(-1, 1, 0).getX(), (double)pPos.add(-1, 1, 0).getY(), (double)pPos.add(-1, 1, 0).getZ()));
        }
        if (((!AutoHoleKick.mc.world.getBlockState(pPos.add(0, 1, 1)).getBlock().equals(Blocks.AIR) || !isNoBBoxBlocked(pPos.add(0, 1, 1))) && (!AutoHoleKick.mc.world.getBlockState(pPos.add(0, 1, 1)).getBlock().equals(Blocks.PISTON) || !BlockUtil.isFacing(pPos.add(0, 1, 1), EnumFacing.NORTH))) || !AutoHoleKick.mc.world.getBlockState(pPos.add(0, 1, -1)).getBlock().equals(Blocks.AIR) || ((!headCheck(pPos) || !AutoHoleKick.mc.world.getBlockState(pPos.add(0, 2, -1)).getBlock().equals(Blocks.AIR)) && !AutoHoleKick.mc.world.getBlockState(pPos.add(0, 0, -1)).getBlock().equals(Blocks.AIR))) {
            if (((AutoHoleKick.mc.world.getBlockState(pPos.add(0, 1, 1)).getBlock().equals(Blocks.AIR) && isNoBBoxBlocked(pPos.add(0, 1, 1))) || (AutoHoleKick.mc.world.getBlockState(pPos.add(0, 1, 1)).getBlock().equals(Blocks.PISTON) && BlockUtil.isFacing(pPos.add(0, 1, 1), EnumFacing.NORTH))) && !AutoHoleKick.mc.world.getBlockState(pPos.add(0, 0, 1)).getBlock().equals(Blocks.AIR) && !AutoHoleKick.mc.world.getBlockState(pPos.add(0, 0, 1)).getBlock().equals(Blocks.REDSTONE_BLOCK) && !AutoHoleKick.mc.world.getBlockState(pPos).getBlock().equals(Blocks.AIR) && AutoHoleKick.mc.world.getBlockState(pPos.add(0, 2, 1)).getBlock().equals(Blocks.AIR) && AutoHoleKick.mc.world.getBlockState(pPos.add(0, 2, 0)).getBlock().equals(Blocks.AIR)) {
                distantMap.put(pPos.add(0, 1, 1), AutoHoleKick.mc.player.getDistance((double)pPos.add(0, 1, 1).getX(), (double)pPos.add(0, 1, 1).getY(), (double)pPos.add(0, 1, 1).getZ()));
            }
        }
        else {
            distantMap.put(pPos.add(0, 1, 1), AutoHoleKick.mc.player.getDistance((double)pPos.add(0, 1, 1).getX(), (double)pPos.add(0, 1, 1).getY(), (double)pPos.add(0, 1, 1).getZ()));
        }
        if (((!AutoHoleKick.mc.world.getBlockState(pPos.add(0, 1, -1)).getBlock().equals(Blocks.AIR) || !isNoBBoxBlocked(pPos.add(0, 1, -1))) && (!AutoHoleKick.mc.world.getBlockState(pPos.add(0, 1, -1)).getBlock().equals(Blocks.PISTON) || !BlockUtil.isFacing(pPos.add(0, 1, -1), EnumFacing.SOUTH))) || !AutoHoleKick.mc.world.getBlockState(pPos.add(0, 1, 1)).getBlock().equals(Blocks.AIR) || ((!headCheck(pPos) || !AutoHoleKick.mc.world.getBlockState(pPos.add(0, 2, 1)).getBlock().equals(Blocks.AIR)) && !AutoHoleKick.mc.world.getBlockState(pPos.add(0, 0, 1)).getBlock().equals(Blocks.AIR))) {
            if (((AutoHoleKick.mc.world.getBlockState(pPos.add(0, 1, -1)).getBlock().equals(Blocks.AIR) && isNoBBoxBlocked(pPos.add(0, 1, -1))) || (AutoHoleKick.mc.world.getBlockState(pPos.add(0, 1, -1)).getBlock().equals(Blocks.PISTON) && BlockUtil.isFacing(pPos.add(0, 1, -1), EnumFacing.SOUTH))) && !AutoHoleKick.mc.world.getBlockState(pPos.add(0, 0, -1)).getBlock().equals(Blocks.AIR) && !AutoHoleKick.mc.world.getBlockState(pPos.add(0, 0, -1)).getBlock().equals(Blocks.REDSTONE_BLOCK) && !AutoHoleKick.mc.world.getBlockState(pPos).getBlock().equals(Blocks.AIR) && AutoHoleKick.mc.world.getBlockState(pPos.add(0, 2, -1)).getBlock().equals(Blocks.AIR) && AutoHoleKick.mc.world.getBlockState(pPos.add(0, 2, 0)).getBlock().equals(Blocks.AIR)) {
                distantMap.put(pPos.add(0, 1, -1), AutoHoleKick.mc.player.getDistance((double)pPos.add(0, 1, -1).getX(), (double)pPos.add(0, 1, -1).getY(), (double)pPos.add(0, 1, -1).getZ()));
            }
        }
        else {
            distantMap.put(pPos.add(0, 1, -1), AutoHoleKick.mc.player.getDistance((double)pPos.add(0, 1, -1).getX(), (double)pPos.add(0, 1, -1).getY(), (double)pPos.add(0, 1, -1).getZ()));
        }
        final List<Map.Entry<BlockPos, Double>> list = new ArrayList<Map.Entry<BlockPos, Double>>(distantMap.entrySet());
        list.sort((Comparator<? super Map.Entry<BlockPos, Double>>)Map.Entry.comparingByValue());
        if (list.size() == 0) {
            return null;
        }
        int i = 0;
        if (this.farPlace.getValue()) {
            for (i = list.size() - 1; i > 0 && list.get(i).getValue() >= this.placeRange.getValue(); --i) {}
        }
        if (InstantMine.breakPos != null) {
            if (list.get(i).getKey().equals((Object)InstantMine.breakPos) && i > 0) {
                --i;
            }
            else if (list.get(i).getKey().equals((Object)InstantMine.breakPos) && i == 0 && this.noPlacePisOnBreakPos.getValue()) {
                return null;
            }
        }
        if (list.get(i).getKey().equals((Object)pPos.add(1, 1, 0))) {
            AutoHoleKick.rotate = -90;
        }
        if (list.get(i).getKey().equals((Object)pPos.add(-1, 1, 0))) {
            AutoHoleKick.rotate = 90;
        }
        if (list.get(i).getKey().equals((Object)pPos.add(0, 1, 1))) {
            AutoHoleKick.rotate = 0;
        }
        if (list.get(i).getKey().equals((Object)pPos.add(0, 1, -1))) {
            AutoHoleKick.rotate = 180;
        }
        return (list.get(i).getValue() > this.placeRange.getValue()) ? null : list.get(i).getKey();
    }
    
    public static boolean isNoBBoxBlocked(final BlockPos pos) {
        final AxisAlignedBB axisAlignedBB = new AxisAlignedBB(pos);
        final List<Entity> l = (List<Entity>)AutoHoleKick.mc.world.getEntitiesWithinAABBExcludingEntity((Entity)null, axisAlignedBB);
        for (final Entity entity : l) {
            if (!(entity instanceof EntityEnderCrystal) && !(entity instanceof EntityItem) && !(entity instanceof EntityArrow) && !(entity instanceof EntityTippedArrow) && !(entity instanceof EntityArrow) && !(entity instanceof EntityXPOrb)) {
                return false;
            }
        }
        return true;
    }
    
    enum surCheckMode
    {
        off, 
        normal, 
        center;
    }
    
    enum page
    {
        render, 
        target, 
        place, 
        breakCry, 
        selfCheck;
    }
    
    public enum FeetPlaceMode
    {
        Obsidian, 
        RedStone;
    }
}
