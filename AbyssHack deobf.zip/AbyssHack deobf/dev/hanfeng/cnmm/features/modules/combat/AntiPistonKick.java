//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.features.modules.combat;

import dev.hanfeng.cnmm.features.modules.*;
import dev.hanfeng.cnmm.features.setting.*;
import net.minecraft.init.*;
import net.minecraft.block.state.*;
import dev.hanfeng.cnmm.features.modules.client.*;
import net.minecraft.util.math.*;
import net.minecraft.block.*;
import dev.hanfeng.cnmm.util.*;
import net.minecraft.util.*;

public class AntiPistonKick extends Module
{
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> head;
    BlockPos pos;
    
    public AntiPistonKick() {
        super("AntiPistonKick", "Anti piston push.", Category.PLAYER, true, false, false);
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)true));
        this.head = (Setting<Boolean>)this.register(new Setting("TrapHead", (T)false));
    }
    
    @Override
    public void onUpdate() {
        this.pos = new BlockPos(AntiPistonKick.mc.player.posX, AntiPistonKick.mc.player.posY, AntiPistonKick.mc.player.posZ);
        if (this.getBlock(this.pos.add(0, 1, 1)).getBlock() == Blocks.PISTON || this.getBlock(this.pos.add(0, 2, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(0, 1, 2)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK) {
            if (this.getBlock(this.pos.add(0, 1, -1)).getBlock() == Blocks.AIR) {
                this.perform(this.pos.add(0, 1, -1));
            }
            if (this.getBlock(this.pos.add(0, 2, -1)).getBlock() == Blocks.AIR) {
                this.perform(this.pos.add(0, 2, -1));
            }
            if (this.getBlock(this.pos.add(0, 1, 1)).getBlock() == Blocks.PISTON) {
                AntiPistonKick.mc.playerController.onPlayerDamageBlock(this.pos.add(0, 1, 1), BlockUtil.getRayTraceFacing(this.pos.add(0, 1, 1)));
            }
            if (this.getBlock(this.pos.add(0, 2, 0)).getBlock() == Blocks.AIR && this.head.getValue()) {
                this.perform(this.pos.add(0, 2, 0));
            }
        }
        if (this.getBlock(this.pos.add(0, 1, -1)).getBlock() == Blocks.PISTON || this.getBlock(this.pos.add(0, 2, -1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(0, 1, -2)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK) {
            if (this.getBlock(this.pos.add(0, 1, 1)).getBlock() == Blocks.AIR) {
                this.perform(this.pos.add(0, 1, 1));
            }
            if (this.getBlock(this.pos.add(0, 2, 1)).getBlock() == Blocks.AIR) {
                this.perform(this.pos.add(0, 2, 1));
            }
            if (this.getBlock(this.pos.add(0, 1, -1)).getBlock() == Blocks.PISTON) {
                AntiPistonKick.mc.playerController.onPlayerDamageBlock(this.pos.add(0, 1, -1), BlockUtil.getRayTraceFacing(this.pos.add(0, 1, -1)));
            }
            if (this.getBlock(this.pos.add(0, 2, 0)).getBlock() == Blocks.AIR && this.head.getValue()) {
                this.perform(this.pos.add(0, 2, 0));
            }
        }
        if (this.getBlock(this.pos.add(1, 1, 0)).getBlock() == Blocks.PISTON || this.getBlock(this.pos.add(1, 2, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(2, 1, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK) {
            if (this.getBlock(this.pos.add(-1, 1, 0)).getBlock() == Blocks.AIR) {
                this.perform(this.pos.add(-1, 1, 0));
            }
            if (this.getBlock(this.pos.add(-1, 2, 0)).getBlock() == Blocks.AIR) {
                this.perform(this.pos.add(-1, 2, 0));
            }
            if (this.getBlock(this.pos.add(1, 1, 0)).getBlock() == Blocks.PISTON) {
                AntiPistonKick.mc.playerController.onPlayerDamageBlock(this.pos.add(1, 1, 0), BlockUtil.getRayTraceFacing(this.pos.add(1, 1, 0)));
            }
            if (this.getBlock(this.pos.add(0, 2, 0)).getBlock() == Blocks.AIR && this.head.getValue()) {
                this.perform(this.pos.add(0, 2, 0));
            }
        }
        if (this.getBlock(this.pos.add(-1, 1, 0)).getBlock() == Blocks.PISTON || this.getBlock(this.pos.add(-1, 2, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-2, 1, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK) {
            if (this.getBlock(this.pos.add(1, 1, 0)).getBlock() == Blocks.AIR) {
                this.perform(this.pos.add(1, 1, 0));
            }
            if (this.getBlock(this.pos.add(1, 2, 0)).getBlock() == Blocks.AIR) {
                this.perform(this.pos.add(1, 2, 0));
            }
            if (this.getBlock(this.pos.add(-1, 1, 0)).getBlock() == Blocks.PISTON) {
                AntiPistonKick.mc.playerController.onPlayerDamageBlock(this.pos.add(-1, 1, 0), BlockUtil.getRayTraceFacing(this.pos.add(-1, 1, 0)));
            }
            if (this.getBlock(this.pos.add(0, 2, 0)).getBlock() == Blocks.AIR && this.head.getValue()) {
                this.perform(this.pos.add(0, 2, 0));
            }
        }
    }
    
    private IBlockState getBlock(final BlockPos block) {
        return AntiPistonKick.mc.world.getBlockState(block);
    }
    
    @Override
    public String getDisplayInfo() {
        if (!HUD.getInstance().moduleInfo.getValue()) {
            return null;
        }
        if (AntiPistonKick.mc.player != null) {
            if (this.getBlock(this.pos.add(-1, 1, 0)).getBlock() == Blocks.PISTON || this.getBlock(this.pos.add(-1, 2, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-2, 1, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK) {
                return "Working";
            }
            if (this.getBlock(this.pos.add(1, 1, 0)).getBlock() == Blocks.PISTON || this.getBlock(this.pos.add(1, 2, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(2, 1, 0)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK) {
                return "Working";
            }
            if (this.getBlock(this.pos.add(0, 1, -1)).getBlock() == Blocks.PISTON || this.getBlock(this.pos.add(0, 2, -1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(0, 1, -2)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, -1)).getBlock() == Blocks.REDSTONE_BLOCK) {
                return "Working";
            }
            if (this.getBlock(this.pos.add(0, 1, 1)).getBlock() == Blocks.PISTON || this.getBlock(this.pos.add(0, 2, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(0, 1, 2)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK || this.getBlock(this.pos.add(-1, 1, 1)).getBlock() == Blocks.REDSTONE_BLOCK) {
                return "Working";
            }
        }
        return null;
    }
    
    private void perform(final BlockPos pos2) {
        final int old = AntiPistonKick.mc.player.inventory.currentItem;
        if (AntiPistonKick.mc.world.getBlockState(pos2).getBlock() == Blocks.AIR) {
            if (InstantMine.breakPos != null && new BlockPos((Vec3i)InstantMine.breakPos).equals((Object)new BlockPos((Vec3i)pos2))) {
                return;
            }
            if (BreakCheck.Instance().BrokenPos != null && new BlockPos((Vec3i)BreakCheck.Instance().BrokenPos).equals((Object)new BlockPos((Vec3i)pos2))) {
                return;
            }
            if (InventoryUtil.findHotbarBlock(BlockObsidian.class) != -1) {
                AntiPistonKick.mc.player.inventory.currentItem = InventoryUtil.findHotbarBlock(BlockObsidian.class);
                AntiPistonKick.mc.playerController.updateController();
                BlockUtil.placeBlock(pos2, EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
                AntiPistonKick.mc.player.inventory.currentItem = old;
                AntiPistonKick.mc.playerController.updateController();
            }
        }
    }
}
