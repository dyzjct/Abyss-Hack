//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.features.modules.combat;

import dev.hanfeng.cnmm.features.modules.*;
import dev.hanfeng.cnmm.features.setting.*;
import net.minecraft.client.renderer.*;
import java.util.*;
import net.minecraft.entity.player.*;
import net.minecraft.entity.*;
import dev.hanfeng.cnmm.*;
import net.minecraft.util.math.*;
import net.minecraft.init.*;
import net.minecraft.block.*;
import net.minecraft.util.*;
import dev.hanfeng.cnmm.util.*;

public class HeadTrap extends Module
{
    private static HeadTrap m_instance;
    private final Setting<Integer> m_sRange;
    private final Setting<Boolean> m_sAutoDisable;
    private final Setting<Boolean> m_sRotate;
    Timer m_delayTimer;
    
    public HeadTrap() {
        super("TopHeadTrap", "Place obsidian in the head of other players!", Category.COMBAT, true, false, false);
        this.m_sRange = (Setting<Integer>)this.register(new Setting("Range", (T)6, (T)0, (T)8));
        this.m_sAutoDisable = (Setting<Boolean>)this.register(new Setting("AutoDisable", (T)false));
        this.m_sRotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)false));
        this.m_delayTimer = new Timer();
        this.setInstance();
    }
    
    public static HeadTrap getInstance() {
        if (HeadTrap.m_instance == null) {
            HeadTrap.m_instance = new HeadTrap();
        }
        return HeadTrap.m_instance;
    }
    
    private void setInstance() {
        HeadTrap.m_instance = this;
    }
    
    @Override
    public void onEnable() {
        this.m_delayTimer.reset();
    }
    
    @Override
    public void onLogout() {
        this.disable();
    }
    
    @Override
    public void onUpdate() {
        if (fullNullCheck()) {
            this.disable();
            return;
        }
        if (!this.shouldPlace()) {
            this.m_delayTimer.reset();
            this.m_delayTimer.passedMs(1000L);
            return;
        }
        if (this.doHeadTopTrap() && this.m_sAutoDisable.getValue()) {
            this.disable();
        }
        this.m_delayTimer.reset();
        this.m_delayTimer.passedMs(100L);
    }
    
    private boolean shouldPlace() {
        for (final Map.Entry<Integer, DestroyBlockProgress> v : HeadTrap.mc.renderGlobal.damagedBlocks.entrySet()) {
            if (v.getValue() != null) {
                final BlockPos blockPos = v.getValue().getPosition();
                final BlockPos headPos = new BlockPos(HeadTrap.mc.player.getPositionVector().add(0.0, 2.0, 0.0));
                if (Math.floor(blockPos.getX()) == Math.floor(headPos.getX()) && Math.floor(blockPos.getY()) == Math.floor(headPos.getY()) && Math.floor(blockPos.getZ()) == Math.floor(headPos.getZ())) {
                    return false;
                }
                continue;
            }
        }
        return true;
    }
    
    private boolean doHeadTopTrap() {
        final EntityPlayer target = this.getTarget(this.m_sRange.getValue());
        if (target == null) {
            return false;
        }
        this.placeBlock(target);
        return this.isHeadTrap(target);
    }
    
    private EntityPlayer getTarget(final double range) {
        EntityPlayer target = null;
        double distance = Math.pow(range, 2.0) + 1.0;
        for (final EntityPlayer player : AutoTrap.mc.world.playerEntities) {
            if (!EntityUtil.isntValid((Entity)player, range) && !this.isHeadTrap(player)) {
                if (AbyssHack.speedManager.getPlayerSpeed(player) > 10.0) {
                    continue;
                }
                if (target == null) {
                    target = player;
                    distance = AutoTrap.mc.player.getDistanceSq((Entity)player);
                }
                else {
                    if (AutoTrap.mc.player.getDistanceSq((Entity)player) >= distance) {
                        continue;
                    }
                    target = player;
                    distance = AutoTrap.mc.player.getDistanceSq((Entity)player);
                }
            }
        }
        return target;
    }
    
    private boolean isHeadTrap(final EntityPlayer player) {
        if (player == null) {
            return true;
        }
        final BlockPos pos = new BlockPos((Entity)player).add(new Vec3i(0, 2, 0));
        return HeadTrap.mc.world.getBlockState(pos).getBlock() == Blocks.OBSIDIAN || HeadTrap.mc.world.getBlockState(pos).getBlock() == Blocks.BEDROCK;
    }
    
    private void placeBlock(final EntityPlayer target) {
        final int originalSlot = InventoryUtil.getSlot();
        final int obSlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
        if (obSlot == -1) {
            return;
        }
        InventoryUtil.switchToHotbarSlot(obSlot, false);
        BlockUtil.placeBlock(new BlockPos(target.getPositionVector()).add(new Vec3i(1, 0, 0)), EnumHand.MAIN_HAND, this.m_sRotate.getValue(), true, false);
        BlockUtil.placeBlock(new BlockPos(target.getPositionVector()).add(new Vec3i(1, 1, 0)), EnumHand.MAIN_HAND, this.m_sRotate.getValue(), true, false);
        BlockUtil.placeBlock(new BlockPos(target.getPositionVector()).add(new Vec3i(1, 2, 0)), EnumHand.MAIN_HAND, this.m_sRotate.getValue(), true, false);
        BlockUtil.placeBlock(new BlockPos(target.getPositionVector()).add(new Vec3i(0, 2, 0)), EnumHand.MAIN_HAND, this.m_sRotate.getValue(), true, false);
        InventoryUtil.switchToHotbarSlot(originalSlot, false);
    }
}
