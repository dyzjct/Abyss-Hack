//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.features.modules.combat;

import dev.hanfeng.cnmm.features.modules.*;
import dev.hanfeng.cnmm.features.setting.*;
import net.minecraft.init.*;
import dev.hanfeng.cnmm.*;
import net.minecraft.util.math.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import net.minecraft.block.state.*;
import net.minecraft.util.*;
import dev.hanfeng.cnmm.util.*;

public class AntiCity extends Module
{
    private final Setting<Boolean> rotate;
    public Setting<Boolean> packet;
    public Setting<Boolean> ac;
    private int obsidian;
    
    public AntiCity() {
        super("AntiCity", "AntiCity", Category.COMBAT, true, false, false);
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)true));
        this.packet = (Setting<Boolean>)this.register(new Setting("Packet", (T)true));
        this.ac = (Setting<Boolean>)this.register(new Setting("AntiCity+", (T)true));
        this.obsidian = -1;
    }
    
    @Override
    public void onUpdate() {
        final Vec3d a = AntiCity.mc.player.getPositionVector();
        this.obsidian = InventoryUtil.findHotbarBlock(Blocks.OBSIDIAN);
        final BlockPos pos = new BlockPos(AntiCity.mc.player.posX, AntiCity.mc.player.posY, AntiCity.mc.player.posZ);
        if (this.obsidian == -1) {
            return;
        }
        if (AbyssHack.moduleManager.isModuleEnabled("Surround")) {
            if (this.getBlock(pos.add(0, 0, -1)).getBlock() != Blocks.BEDROCK) {
                this.perform(pos.add(0, 0, -1));
                this.perform(pos.add(0, 0, -2));
                this.perform(pos.add(0, 1, -2));
                this.perform(pos.add(1, 0, -1));
                this.perform(pos.add(-1, 0, -1));
                if (this.ac.getValue()) {
                    this.perform(pos.add(0, 1, -1));
                }
            }
            if (this.getBlock(pos.add(0, 0, 1)).getBlock() != Blocks.BEDROCK) {
                this.perform(pos.add(0, 0, 1));
                this.perform(pos.add(0, 0, 2));
                this.perform(pos.add(0, 1, 2));
                this.perform(pos.add(1, 0, 1));
                this.perform(pos.add(-1, 0, 1));
                if (this.ac.getValue()) {
                    this.perform(pos.add(0, 1, 1));
                }
            }
            if (this.getBlock(pos.add(1, 0, 0)).getBlock() != Blocks.BEDROCK) {
                this.perform(pos.add(1, 0, 0));
                this.perform(pos.add(2, 0, 0));
                this.perform(pos.add(2, 1, 0));
                this.perform(pos.add(1, 0, 1));
                this.perform(pos.add(1, 0, -1));
                if (this.ac.getValue()) {
                    this.perform(pos.add(1, 1, 0));
                }
            }
            if (this.getBlock(pos.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK) {
                this.perform(pos.add(-1, 0, 0));
                this.perform(pos.add(-2, 0, 0));
                this.perform(pos.add(-2, 1, 0));
                this.perform(pos.add(-1, 0, 1));
                this.perform(pos.add(-1, 0, -1));
                if (this.ac.getValue()) {
                    this.perform(pos.add(-1, 1, 0));
                }
            }
        }
    }
    
    private void switchToSlot(final int slot) {
        AntiCity.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot));
        AntiCity.mc.player.inventory.currentItem = slot;
        AntiCity.mc.playerController.updateController();
    }
    
    private IBlockState getBlock(final BlockPos block) {
        return AntiCity.mc.world.getBlockState(block);
    }
    
    private void perform(final BlockPos pos) {
        if (this.getBlock(pos).getBlock() == Blocks.AIR) {
            final int old = AntiCity.mc.player.inventory.currentItem;
            this.switchToSlot(this.obsidian);
            BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
            this.switchToSlot(old);
        }
    }
}
