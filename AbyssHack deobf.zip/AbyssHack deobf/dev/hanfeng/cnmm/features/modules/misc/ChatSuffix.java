//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.features.modules.misc;

import dev.hanfeng.cnmm.features.modules.*;
import dev.hanfeng.cnmm.event.events.*;
import net.minecraft.network.play.client.*;
import net.minecraftforge.fml.common.eventhandler.*;

public class ChatSuffix extends Module
{
    public ChatSuffix() {
        super("ChatSuffix", "suffix", Category.MISC, true, false, false);
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send event) {
        if (event.getStage() == 0 && event.getPacket() instanceof CPacketChatMessage) {
            final CPacketChatMessage packet = (CPacketChatMessage)event.getPacket();
            final String message = packet.getMessage();
            if (!message.startsWith("/")) {
                String abHackChat = message + " | AbyssHack";
                if (abHackChat.length() >= 256) {
                    abHackChat = abHackChat.substring(0, 256);
                }
                packet.message = abHackChat;
            }
        }
    }
}
