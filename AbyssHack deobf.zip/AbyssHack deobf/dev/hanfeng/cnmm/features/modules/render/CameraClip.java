//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.features.modules.render;

import dev.hanfeng.cnmm.features.modules.*;
import dev.hanfeng.cnmm.features.setting.*;

public class CameraClip extends Module
{
    public Setting<Double> distance;
    
    public CameraClip() {
        super("CameraClip", "Allow Camera pierce through.", Module.Category.RENDER, false, false, false);
        this.distance = (Setting<Double>)this.register(new Setting("Distance", (T)4.0, (T)(-10.0), (T)20.0));
    }
}
