//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.features.modules.movement;

import dev.hanfeng.cnmm.features.modules.*;

public class Sprint extends Module
{
    public Sprint() {
        super("Sprint", "Force sprint.", Module.Category.MOVEMENT, true, false, false);
    }
    
    public void onTick() {
        if ((Sprint.mc.player.moveForward != 0.0f || Sprint.mc.player.moveStrafing != 0.0f) && !Sprint.mc.player.isSprinting()) {
            Sprint.mc.player.setSprinting(true);
        }
    }
}
