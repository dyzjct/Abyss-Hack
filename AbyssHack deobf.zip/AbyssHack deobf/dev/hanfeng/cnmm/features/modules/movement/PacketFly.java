//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.features.modules.movement;

import dev.hanfeng.cnmm.features.modules.*;

public class PacketFly extends Module
{
    public PacketFly() {
        super("PacketFly", "PacketFly.", Module.Category.MOVEMENT, true, false, false);
    }
}
