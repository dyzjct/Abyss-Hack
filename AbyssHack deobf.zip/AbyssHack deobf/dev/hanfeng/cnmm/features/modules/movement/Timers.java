//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.features.modules.movement;

import dev.hanfeng.cnmm.features.modules.*;
import java.util.concurrent.*;
import net.minecraft.network.*;
import dev.hanfeng.cnmm.features.setting.*;
import dev.hanfeng.cnmm.util.*;
import dev.hanfeng.cnmm.event.events.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.play.server.*;
import net.minecraftforge.fml.common.eventhandler.*;

public class Timers extends Module
{
    public static CopyOnWriteArrayList<Packet<?>> packetList;
    private final Setting<Float> tickNormal;
    private final Setting<Boolean> bypass;
    public final Setting<Float> speedvalue;
    private final Setting<Boolean> setrotate;
    public int i;
    public int x;
    private float yaw;
    private float pitch;
    private final Timer timer;
    private boolean cancelPackets;
    private boolean timerReset;
    int ticked;
    
    public Timers() {
        super("Timer", "Change client running speed.", Module.Category.MOVEMENT, true, false, false);
        this.tickNormal = (Setting<Float>)this.register(new Setting("Speed", (T)1.2f, (T)1.0f, (T)10.0f));
        this.bypass = (Setting<Boolean>)this.register(new Setting("Bypass", (T)true));
        this.speedvalue = (Setting<Float>)this.register(new Setting("SpeedValue", (T)0.0f, (T)0.0f, (T)100.0f, v -> this.bypass.getValue()));
        this.setrotate = (Setting<Boolean>)this.register(new Setting("SetRotate", (T)true, v -> this.bypass.getValue()));
        this.i = 0;
        this.x = 0;
        this.yaw = 0.0f;
        this.pitch = 0.0f;
        this.timer = new Timer();
        this.cancelPackets = true;
        this.timerReset = false;
        this.ticked = 79;
    }
    
    public void onDisable() {
        Timers.mc.timer.tickLength = 50.0f;
        Timers.packetList.clear();
    }
    
    public void onEnable() {
        Timers.mc.timer.tickLength = 50.0f;
        Timers.packetList.clear();
    }
    
    public void onUpdate() {
        if (this.timerReset && !this.cancelPackets) {
            this.cancelPackets = true;
            this.timerReset = false;
        }
        if (this.bypass.getValue()) {
            if (this.i <= this.speedvalue.getValue()) {
                ++this.i;
                Timers.mc.timer.tickLength = 50.0f / this.tickNormal.getValue();
                this.x = 0;
            }
            else if (this.x <= this.speedvalue.getValue() - this.speedvalue.getValue() / 2.0f / 2.0f) {
                ++this.x;
                Timers.mc.timer.tickLength = 50.0f;
            }
            else {
                this.i = 0;
            }
        }
        else {
            Timers.mc.timer.tickLength = 50.0f / this.tickNormal.getValue();
        }
    }
    
    public void onTick() {
        if (this.bypass.getValue() && this.setrotate.getValue()) {
            ++this.ticked;
            if (this.ticked >= 79) {
                this.yaw = Timers.mc.player.rotationYaw;
                this.pitch = Timers.mc.player.rotationPitch;
                this.ticked = 0;
            }
        }
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send event) {
        if (event.getPacket() instanceof CPacketPlayer && !Timers.packetList.contains(event.getPacket())) {
            Timers.packetList.add((Packet<?>)event.getPacket());
        }
        if (event.getStage() == 0 && this.setrotate.getValue() && this.cancelPackets && event.getPacket() instanceof SPacketPlayerPosLook) {
            final SPacketPlayerPosLook packet = (SPacketPlayerPosLook)event.getPacket();
            packet.yaw = this.yaw;
            packet.pitch = this.pitch;
        }
    }
    
    public void onLogout() {
        this.cancelPackets = false;
    }
    
    public void onLogin() {
        this.timer.reset();
        this.timerReset = true;
    }
    
    static {
        Timers.packetList = new CopyOnWriteArrayList<Packet<?>>();
    }
}
