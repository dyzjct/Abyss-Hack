//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.features.command.commands;

import dev.hanfeng.cnmm.features.command.*;
import dev.hanfeng.cnmm.*;
import com.mojang.realmsclient.gui.*;
import java.util.*;

public class HelpCommand extends Command
{
    public HelpCommand() {
        super("help");
    }
    
    public void execute(final String[] commands) {
        sendMessage("Commands: ");
        for (final Command command : AbyssHack.commandManager.getCommands()) {
            sendMessage(ChatFormatting.GRAY + AbyssHack.commandManager.getPrefix() + command.getName());
        }
    }
}
