//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.manager;

import dev.hanfeng.cnmm.util.*;
import net.minecraft.entity.*;

public class TargetManager implements Globals
{
    private EntityLivingBase currentTarget;
    
    public TargetManager() {
        this.currentTarget = null;
    }
    
    public void updateTarget(final EntityLivingBase targetIn) {
        this.currentTarget = targetIn;
    }
    
    public EntityLivingBase getTarget() {
        return this.currentTarget;
    }
}
