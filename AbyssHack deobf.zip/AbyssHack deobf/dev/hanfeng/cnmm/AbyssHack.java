//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm;

import net.minecraftforge.fml.common.*;
import dev.hanfeng.cnmm.notification.*;
import dev.hanfeng.cnmm.manager.*;
import net.minecraftforge.fml.common.event.*;
import net.minecraft.util.*;
import java.nio.*;
import dev.hanfeng.cnmm.util.*;
import org.lwjgl.opengl.*;
import java.io.*;
import org.apache.logging.log4j.*;

@Mod(modid = "abysshack", name = "AbyssHack", version = "0.1")
public class AbyssHack
{
    public static final String MODID = "abysshack";
    public static final String MODNAME = "AbyssHack";
    public static final String MODVER = "0.2";
    public static final Logger LOGGER;
    public static CommandManager commandManager;
    public static FriendManager friendManager;
    public static ModuleManager moduleManager;
    public static NotificationsManager notificationsManager;
    public static PacketManager packetManager;
    public static ColorManager colorManager;
    public static HoleManager holeManager;
    public static InventoryManager inventoryManager;
    public static PotionManager potionManager;
    public static RotationManager rotationManager;
    public static PositionManager positionManager;
    public static SpeedManager speedManager;
    public static ReloadManager reloadManager;
    public static FileManager fileManager;
    public static ConfigManager configManager;
    public static ServerManager serverManager;
    public static EventManager eventManager;
    public static TextManager textManager;
    public static TargetManager targetManager;
    @Mod.Instance
    public static AbyssHack INSTANCE;
    private static boolean unloaded;
    public static boolean shouldLoad;
    
    public static void load() {
        AbyssHack.LOGGER.info("\n\nLoading AbyssHack");
        AbyssHack.unloaded = false;
        if (AbyssHack.reloadManager != null) {
            AbyssHack.reloadManager.unload();
            AbyssHack.reloadManager = null;
        }
        AbyssHack.targetManager = new TargetManager();
        AbyssHack.notificationsManager = new NotificationsManager();
        AbyssHack.textManager = new TextManager();
        AbyssHack.commandManager = new CommandManager();
        AbyssHack.friendManager = new FriendManager();
        AbyssHack.moduleManager = new ModuleManager();
        AbyssHack.rotationManager = new RotationManager();
        AbyssHack.packetManager = new PacketManager();
        AbyssHack.eventManager = new EventManager();
        AbyssHack.speedManager = new SpeedManager();
        AbyssHack.potionManager = new PotionManager();
        AbyssHack.inventoryManager = new InventoryManager();
        AbyssHack.serverManager = new ServerManager();
        AbyssHack.fileManager = new FileManager();
        AbyssHack.colorManager = new ColorManager();
        AbyssHack.positionManager = new PositionManager();
        AbyssHack.configManager = new ConfigManager();
        AbyssHack.holeManager = new HoleManager();
        AbyssHack.LOGGER.info("Managers loaded.");
        AbyssHack.moduleManager.init();
        AbyssHack.LOGGER.info("Modules loaded.");
        AbyssHack.configManager.init();
        AbyssHack.eventManager.init();
        AbyssHack.LOGGER.info("EventManager loaded.");
        AbyssHack.textManager.init(true);
        AbyssHack.moduleManager.onLoad();
        AbyssHack.LOGGER.info("OyVey successfully loaded!\n");
        try {
            loader();
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    public static void unload(final boolean unload) {
        AbyssHack.LOGGER.info("\n\nUnloading AbyssHack");
        if (unload) {
            (AbyssHack.reloadManager = new ReloadManager()).init((AbyssHack.commandManager != null) ? AbyssHack.commandManager.getPrefix() : ".");
        }
        onUnload();
        AbyssHack.targetManager = null;
        AbyssHack.notificationsManager = null;
        AbyssHack.eventManager = null;
        AbyssHack.friendManager = null;
        AbyssHack.speedManager = null;
        AbyssHack.holeManager = null;
        AbyssHack.positionManager = null;
        AbyssHack.rotationManager = null;
        AbyssHack.configManager = null;
        AbyssHack.commandManager = null;
        AbyssHack.colorManager = null;
        AbyssHack.serverManager = null;
        AbyssHack.fileManager = null;
        AbyssHack.potionManager = null;
        AbyssHack.inventoryManager = null;
        AbyssHack.moduleManager = null;
        AbyssHack.textManager = null;
        AbyssHack.LOGGER.info("AbyssHack unloaded!\n");
    }
    
    public static void reload() {
        unload(false);
        load();
    }
    
    public static void onUnload() {
        if (!AbyssHack.unloaded) {
            AbyssHack.eventManager.onUnload();
            AbyssHack.moduleManager.onUnload();
            AbyssHack.configManager.saveConfig(AbyssHack.configManager.config.replaceFirst("AbyssHack/", ""));
            AbyssHack.moduleManager.onUnloadPost();
            AbyssHack.unloaded = true;
        }
    }
    
    public static void loader() throws Exception {
        AbyssHack.shouldLoad = true;
    }
    
    @Mod.EventHandler
    public void preInit(final FMLPreInitializationEvent event) {
        AbyssHack.LOGGER.info("AbyssHack");
    }
    
    @Mod.EventHandler
    public void init(final FMLInitializationEvent event) {
        if (Util.getOSType() != Util.EnumOS.OSX) {
            try (final InputStream inputStream16x = AbyssHack.class.getResourceAsStream("/assets/minecraft/textures/icon-16x.png");
                 final InputStream inputStream32x = AbyssHack.class.getResourceAsStream("/assets/minecraft/textures/icon-32x.png")) {
                final ByteBuffer[] icons = { IconUtil.INSTANCE.readImageToBuffer(inputStream16x), IconUtil.INSTANCE.readImageToBuffer(inputStream32x) };
                Display.setIcon(icons);
            }
            catch (Exception e) {
                AbyssHack.LOGGER.error("Couldn't set Windows Icon", (Throwable)e);
            }
        }
        Display.setTitle("AbyssHack0.2");
        load();
    }
    
    static {
        LOGGER = LogManager.getLogger("abysshack");
        AbyssHack.shouldLoad = true;
        AbyssHack.unloaded = false;
    }
}
