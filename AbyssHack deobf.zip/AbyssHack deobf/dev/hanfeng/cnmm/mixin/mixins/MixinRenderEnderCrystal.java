//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.mixin.mixins;

import net.minecraft.client.renderer.entity.*;
import net.minecraft.util.*;
import org.spongepowered.asm.mixin.*;
import net.minecraft.client.model.*;
import net.minecraft.entity.item.*;
import net.minecraft.entity.*;
import dev.hanfeng.cnmm.features.modules.render.*;
import net.minecraft.client.renderer.*;
import dev.hanfeng.cnmm.event.events.*;
import org.lwjgl.opengl.*;
import dev.hanfeng.cnmm.features.modules.client.*;
import java.awt.*;
import dev.hanfeng.cnmm.util.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import net.minecraft.client.*;
import org.spongepowered.asm.mixin.injection.*;

@Mixin({ RenderEnderCrystal.class })
public abstract class MixinRenderEnderCrystal
{
    @Final
    @Shadow
    private static ResourceLocation ENDER_CRYSTAL_TEXTURES;
    @Shadow
    public ModelBase modelEnderCrystal;
    @Shadow
    public ModelBase modelEnderCrystalNoBase;
    
    @Shadow
    public abstract void doRender(final EntityEnderCrystal p0, final double p1, final double p2, final double p3, final float p4, final float p5);
    
    @Redirect(method = { "doRender" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/ModelBase;render(Lnet/minecraft/entity/Entity;FFFFFF)V"))
    public void renderModelBaseHook(final ModelBase model, final Entity entity, final float limbSwing, final float limbSwingAmount, final float ageInTicks, final float netHeadYaw, final float headPitch, final float scale) {
        if (CrystalChams.INSTANCE.isEnabled()) {
            GlStateManager.scale((float)CrystalChams.INSTANCE.scale.getValue(), (float)CrystalChams.INSTANCE.scale.getValue(), (float)CrystalChams.INSTANCE.scale.getValue());
        }
        if (CrystalChams.INSTANCE.isEnabled() && (boolean)CrystalChams.INSTANCE.wireframe.getValue()) {
            final RenderEntityModelEvent event = new RenderEntityModelEvent(0, model, entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
            CrystalChams.INSTANCE.onRenderModel(event);
        }
        if (CrystalChams.INSTANCE.isEnabled() && (boolean)CrystalChams.INSTANCE.chams.getValue()) {
            GL11.glPushAttrib(1048575);
            GL11.glDisable(3008);
            GL11.glDisable(3553);
            GL11.glDisable(2896);
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            GL11.glLineWidth(1.5f);
            GL11.glEnable(2960);
            if (CrystalChams.INSTANCE.rainbow.getValue()) {
                final Color rainbowColor1 = CrystalChams.INSTANCE.rainbow.getValue() ? ColorUtil.rainbow((int)ClickGui.getInstance().rainbowHue.getValue()) : new Color(RenderUtil.getRainbow((int)CrystalChams.INSTANCE.speed.getValue() * 100, 0, (int)CrystalChams.INSTANCE.saturation.getValue() / 100.0f, (int)CrystalChams.INSTANCE.brightness.getValue() / 100.0f));
                final Color rainbowColor2 = EntityUtil.getColor(entity, rainbowColor1.getRed(), rainbowColor1.getGreen(), rainbowColor1.getBlue(), (int)CrystalChams.INSTANCE.alpha.getValue(), true);
                if (CrystalChams.INSTANCE.throughWalls.getValue()) {
                    GL11.glDisable(2929);
                    GL11.glDepthMask(false);
                }
                GL11.glEnable(10754);
                GL11.glColor4f(rainbowColor2.getRed() / 255.0f, rainbowColor2.getGreen() / 255.0f, rainbowColor2.getBlue() / 255.0f, (int)CrystalChams.INSTANCE.alpha.getValue() / 255.0f);
                model.render(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
                if (CrystalChams.INSTANCE.throughWalls.getValue()) {
                    GL11.glEnable(2929);
                    GL11.glDepthMask(true);
                }
            }
            else if ((boolean)CrystalChams.INSTANCE.xqz.getValue() && (boolean)CrystalChams.INSTANCE.throughWalls.getValue()) {
                final Color hiddenColor = EntityUtil.getColor(entity, (int)CrystalChams.INSTANCE.hiddenRed.getValue(), (int)CrystalChams.INSTANCE.hiddenGreen.getValue(), (int)CrystalChams.INSTANCE.hiddenBlue.getValue(), (int)CrystalChams.INSTANCE.hiddenAlpha.getValue(), true);
                final Color visibleColor;
                final Color color = visibleColor = EntityUtil.getColor(entity, (int)CrystalChams.INSTANCE.red.getValue(), (int)CrystalChams.INSTANCE.green.getValue(), (int)CrystalChams.INSTANCE.blue.getValue(), (int)CrystalChams.INSTANCE.alpha.getValue(), true);
                if (CrystalChams.INSTANCE.throughWalls.getValue()) {
                    GL11.glDisable(2929);
                    GL11.glDepthMask(false);
                }
                GL11.glEnable(10754);
                GL11.glColor4f(hiddenColor.getRed() / 255.0f, hiddenColor.getGreen() / 255.0f, hiddenColor.getBlue() / 255.0f, (int)CrystalChams.INSTANCE.alpha.getValue() / 255.0f);
                model.render(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
                if (CrystalChams.INSTANCE.throughWalls.getValue()) {
                    GL11.glEnable(2929);
                    GL11.glDepthMask(true);
                }
                GL11.glColor4f(visibleColor.getRed() / 255.0f, visibleColor.getGreen() / 255.0f, visibleColor.getBlue() / 255.0f, (int)CrystalChams.INSTANCE.alpha.getValue() / 255.0f);
                model.render(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
            }
            else {
                final Color visibleColor2;
                final Color color2 = visibleColor2 = (CrystalChams.INSTANCE.rainbow.getValue() ? ColorUtil.rainbow((int)ClickGui.getInstance().rainbowHue.getValue()) : EntityUtil.getColor(entity, (int)CrystalChams.INSTANCE.red.getValue(), (int)CrystalChams.INSTANCE.green.getValue(), (int)CrystalChams.INSTANCE.blue.getValue(), (int)CrystalChams.INSTANCE.alpha.getValue(), true));
                if (CrystalChams.INSTANCE.throughWalls.getValue()) {
                    GL11.glDisable(2929);
                    GL11.glDepthMask(false);
                }
                GL11.glEnable(10754);
                GL11.glColor4f(visibleColor2.getRed() / 255.0f, visibleColor2.getGreen() / 255.0f, visibleColor2.getBlue() / 255.0f, (int)CrystalChams.INSTANCE.alpha.getValue() / 255.0f);
                model.render(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
                if (CrystalChams.INSTANCE.throughWalls.getValue()) {
                    GL11.glEnable(2929);
                    GL11.glDepthMask(true);
                }
            }
            GL11.glEnable(3042);
            GL11.glEnable(2896);
            GL11.glEnable(3553);
            GL11.glEnable(3008);
            GL11.glPopAttrib();
        }
        else {
            model.render(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
        }
        if (CrystalChams.INSTANCE.isEnabled()) {
            GlStateManager.scale(1.0f / (float)CrystalChams.INSTANCE.scale.getValue(), 1.0f / (float)CrystalChams.INSTANCE.scale.getValue(), 1.0f / (float)CrystalChams.INSTANCE.scale.getValue());
        }
    }
    
    @Inject(method = { "doRender(Lnet/minecraft/entity/item/EntityEnderCrystal;DDDFF)V" }, at = { @At("RETURN") }, cancellable = true)
    public void IdoRender(final EntityEnderCrystal var1, final double var2, final double var4, final double var6, final float var8, final float var9, final CallbackInfo var10) {
        final Minecraft mc = Minecraft.getMinecraft();
        mc.gameSettings.fancyGraphics = false;
    }
}
