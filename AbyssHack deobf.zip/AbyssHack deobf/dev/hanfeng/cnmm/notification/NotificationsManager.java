//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.notification;

import java.util.*;

public class NotificationsManager
{
    public static ArrayList<Notification> notifications;
    
    public void add(final Notification noti) {
        noti.y = (float)(NotificationsManager.notifications.size() * 25);
        NotificationsManager.notifications.add(noti);
    }
    
    public void draw(final float speed) {
        try {
            int i = 0;
            Notification remove = null;
            for (final Notification notification : NotificationsManager.notifications) {
                if (notification.x == 0.0f) {
                    notification.in = !notification.in;
                }
                if (Math.abs(notification.x - notification.width) < 0.1 && !notification.in) {
                    remove = notification;
                }
                if (notification.in) {
                    notification.x = notification.animationUtils.animate(0.0f, notification.x, speed / 10.0f);
                }
                else {
                    notification.x = notification.animationUtils.animate(notification.width, notification.x, speed / 10.0f);
                }
                notification.onRender();
                ++i;
            }
            if (remove != null) {
                NotificationsManager.notifications.remove(remove);
            }
        }
        catch (ConcurrentModificationException e) {
            e.printStackTrace();
        }
    }
    
    static {
        NotificationsManager.notifications = new ArrayList<Notification>();
    }
}
