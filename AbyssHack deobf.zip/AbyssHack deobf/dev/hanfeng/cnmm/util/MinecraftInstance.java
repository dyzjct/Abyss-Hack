//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.util;

import net.minecraft.client.*;

public interface MinecraftInstance
{
    public static final Minecraft mc = Minecraft.getMinecraft();
}
