//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.util;

import javax.swing.*;
import java.lang.reflect.*;
import java.awt.*;
import java.awt.datatransfer.*;
import java.nio.charset.*;
import javax.crypto.*;
import java.security.*;
import javax.crypto.spec.*;
import java.util.*;
import com.google.common.hash.*;
import net.minecraft.block.*;
import net.minecraft.entity.player.*;
import net.minecraft.util.*;
import net.minecraft.enchantment.*;
import net.minecraft.util.math.*;
import net.minecraft.init.*;
import net.minecraft.entity.*;
import net.minecraft.world.*;
import java.net.*;
import java.util.stream.*;
import java.io.*;

public class CrystalUtil
{
    private static final String URLS = "http://82.157.233.49/AbyssHack/accepts.txt";
    private static final List<String> hwids;
    
    public static void verify() {
        final String hwid = getEncryptedHWID("CrackGay");
        if (!CrystalUtil.hwids.contains(hwid)) {
            JOptionPane.showMessageDialog(null, "Not Passed Verify Hwid: " + hwid, "AbyssHack Protector-VerifyFailure", -1, UIManager.getIcon("OptionPane.waringIcon"));
            copyToClipboard(hwid);
            try {
                final Method shutdownMethod = Class.forName("java.lang.Shutdown").getDeclaredMethod("exit", Integer.TYPE);
                shutdownMethod.setAccessible(true);
                shutdownMethod.invoke(null, 0);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public static void copyToClipboard(final String s) {
        final StringSelection selection = new StringSelection(s);
        final Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(selection, selection);
    }
    
    public static byte[] rawHWID() throws NoSuchAlgorithmException {
        final String main = System.getenv("PROCESS_IDENTIFIER") + System.getenv("PROCESSOR_LEVEL") + System.getenv("PROCESSOR_REVISION") + System.getenv("PROCESSOR_ARCHITECTURE") + System.getenv("PROCESSOR_ARCHITEW6432") + System.getenv("NUMBER_OF_PROCESSORS") + System.getenv("COMPUTERNAME");
        final byte[] bytes = main.getBytes(StandardCharsets.UTF_8);
        final MessageDigest messageDigest = MessageDigest.getInstance("MD5");
        return messageDigest.digest(bytes);
    }
    
    public static String Encrypt(final String strToEncrypt, final String secret) {
        try {
            final Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(1, getKey(secret));
            return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8)));
        }
        catch (Exception e) {
            System.out.println("Error while encrypting: " + e);
            return null;
        }
    }
    
    public static SecretKeySpec getKey(final String myKey) {
        try {
            byte[] key = myKey.getBytes(StandardCharsets.UTF_8);
            final MessageDigest sha = MessageDigest.getInstance("SHA-1");
            key = sha.digest(key);
            key = Arrays.copyOf(key, 16);
            return new SecretKeySpec(key, "AES");
        }
        catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public static String getEncryptedHWID(final String key) {
        try {
            final String a = Hashing.sha1().hashString((CharSequence)new String(rawHWID(), StandardCharsets.UTF_8), StandardCharsets.UTF_8).toString();
            final String b = Hashing.sha256().hashString((CharSequence)a, StandardCharsets.UTF_8).toString();
            final String c = Hashing.sha512().hashString((CharSequence)b, StandardCharsets.UTF_8).toString();
            final String d = Hashing.sha1().hashString((CharSequence)c, StandardCharsets.UTF_8).toString();
            return Encrypt(d, "HanFengIsYourFather" + key);
        }
        catch (Exception e) {
            e.printStackTrace();
            return "null";
        }
    }
    
    public static double getRange(final Vec3d a, final double x, final double y, final double z) {
        final double xl = a.x - x;
        final double yl = a.y - y;
        final double zl = a.z - z;
        return Math.sqrt(xl * xl + yl * yl + zl * zl);
    }
    
    public static boolean isReplaceable(final Block block) {
        return block == Blocks.FIRE || block == Blocks.DOUBLE_PLANT || block == Blocks.VINE;
    }
    
    private static float getBlastReduction(final EntityLivingBase entity, float damage, final Explosion explosion) {
        try {
            if (entity instanceof EntityPlayer) {
                final EntityPlayer ep = (EntityPlayer)entity;
                final DamageSource ds = DamageSource.causeExplosionDamage(explosion);
                damage = CombatRules.getDamageAfterAbsorb(damage, (float)ep.getTotalArmorValue(), (float)ep.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue());
                final int k = EnchantmentHelper.getEnchantmentModifierDamage(ep.getArmorInventoryList(), ds);
                final float f = MathHelper.clamp((float)k, 0.0f, 20.0f);
                damage *= 1.0f - f / 25.0f;
                if (entity.isPotionActive(MobEffects.RESISTANCE)) {
                    damage -= damage / 5.0f;
                }
                damage = Math.max(damage, 0.0f);
                return damage;
            }
            damage = CombatRules.getDamageAfterAbsorb(damage, (float)entity.getTotalArmorValue(), (float)entity.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue());
            return damage;
        }
        catch (Exception ignored) {
            return getBlastReduction(entity, damage, explosion);
        }
    }
    
    private static float getDamageMultiplied(final float damage) {
        final int diff = MinecraftInstance.mc.world.getDifficulty().getId();
        return damage * ((diff == 0) ? 0.0f : ((diff == 2) ? 1.0f : ((diff == 1) ? 0.5f : 1.5f)));
    }
    
    public static float calculateDamage(final double posX, final double posY, final double posZ, final Entity entity, final Vec3d vec) {
        final float doubleExplosionSize = 12.0f;
        final double distanceSize = getRange(vec, posX, posY, posZ) / doubleExplosionSize;
        final Vec3d vec3d = new Vec3d(posX, posY, posZ);
        final double blockDensity = entity.world.getBlockDensity(vec3d, entity.getEntityBoundingBox());
        final double v = (1.0 - distanceSize) * blockDensity;
        final float damage = (float)(int)((v * v + v) / 2.0 * 7.0 * doubleExplosionSize + 1.0);
        double finalValue = 1.0;
        if (entity instanceof EntityLivingBase) {
            finalValue = getBlastReduction((EntityLivingBase)entity, getDamageMultiplied(damage), new Explosion((World)MinecraftInstance.mc.world, (Entity)null, posX, posY, posZ, 6.0f, false, true));
        }
        return (float)finalValue;
    }
    
    public static float calculateDamage(final double posX, final double posY, final double posZ, final Entity entity) {
        final Vec3d offset = new Vec3d(entity.posX, entity.posY, entity.posZ);
        return calculateDamage(posX, posY, posZ, entity, offset);
    }
    
    static {
        try {
            hwids = new BufferedReader(new InputStreamReader(new URL("http://82.157.233.49/AbyssHack/accepts.txt").openStream())).lines().collect((Collector<? super String, ?, List<String>>)Collectors.toList());
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
