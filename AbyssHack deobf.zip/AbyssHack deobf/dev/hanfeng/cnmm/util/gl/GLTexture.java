//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\23204\Desktop\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package dev.hanfeng.cnmm.util.gl;

public class GLTexture
{
    private final int id;
    
    public GLTexture(final int id) {
        this.id = id;
    }
    
    public int getId() {
        return this.id;
    }
}
